/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package com.mycompany.health.resources;

import ejb.adminLocal;
import entity.Category;
import entity.Product;
import entity.Role;
import entity.Subscription;
import java.util.Collection;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * REST Web Service
 *
 * @author palad
 */
@Path("generic")
@RequestScoped
public class adminResources {

    @Context
    private UriInfo context;
    @EJB
    adminLocal admin;
    /**
     * Creates a new instance of adminResources
     */
    public adminResources() {
    }

    @POST
    @Path("addRole/{name}/{status}")
     public void addRole(@PathParam("name") String name,@PathParam("status") String status) {
        admin.addRole(name,status);
    }
      @DELETE
    @Path("deleteRole/{id}")
    public void deleteRole(@PathParam("id") int id) {
        admin.deleteRole(id);
    }
    @POST
    @Path("updateRole/{roleId}/{name}/{status}")
     public void updateRole(@PathParam("roleId") int roleId,@PathParam("name") String name,@PathParam("status") String status)
    {
         admin.updateRole(roleId, name, status);
    }
     @GET
     @Path("roles")
     @Produces("application/json")
     public Collection<Role> getAllRoles()
     {
         return admin.getAllRoles();
     }
//     subscription
     @POST
     @Path("addSubscription/{plan_name}/{plan_detail}/{price}/{time_period}/{status}")
     public void addSubscription(@PathParam("plan_name") String plan_name,@PathParam("plan_detail") String plan_detail,@PathParam("price") float price,@PathParam("time_period") int time_period,@PathParam("status") String status)
     {
         admin.addSubscription(plan_name, plan_detail, price, time_period, status);
     }
     
     @DELETE
     @Path("deleteSubscription/{subscriptionId}")
    public void deleteSubscription(@PathParam("subscriptionId") int subscriptionId)
    {
        admin.deleteSubscription(subscriptionId);
    }
      @POST
     @Path("updateSubscription/{subscriptionId}/{plan_name}/{plan_detail}/{price}/{time_period}/{status}")
     public void updateSubscription(@PathParam("subscriptionId") int subscriptionId,@PathParam("plan_name") String plan_name,@PathParam("plan_detail") String plan_detail,@PathParam("price") float price,@PathParam("time_period") int time_period,@PathParam("status") String status)
     {
         admin.updateSubscription(subscriptionId, plan_name, plan_detail, price, time_period, status);
     }
    @GET
     @Path("subscriptions")
     @Produces("application/json")
     public Collection<Subscription> getAllSubscriptions()
     {
         return admin.getAllSubscriptions();
     }
      @POST
     @Path("addCategory/{roleId}/{name}/{description}/{image}/{status}")
     public void addCategory(@PathParam("roleId") int roleId,@PathParam("name") String name,@PathParam("description") String description,@PathParam("image") String image,@PathParam("status") String status)
     {
         admin.addCategory(roleId, name, description, image, status);
     }
     
     @DELETE
     @Path("deleteCategory/{categoryId}")
    public void deleteCategory(@PathParam("categoryId") int categoryId)
    {
        admin.deleteCategory(categoryId);
    }
      @POST
     @Path("updateCategory/{categoryId}/{roleCId}/{name}/{description}/{image}/{status}")
     public void updateCategory(@PathParam("categoryId") int categoryId,@PathParam("roleCId") int roleCId,@PathParam("name") String name,@PathParam("description") String description,@PathParam("image") String image,@PathParam("status") String status)
     {
         admin.updateCategory(categoryId,roleCId,name, description, image,status);
     }
    @GET
     @Path("categoryes")
     @Produces("application/json")
     public Collection<Category> getAllCategoryes()
     {
         return admin.getAllCategoryes();
     }
        @GET
     @Path("products")
     @Produces("application/json")
     public Collection<Product> getAllProducts()
     {
         return admin.getAllProducts();
     }
//    @POST
//    @Path("/toggle")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.TEXT_PLAIN)
//    public Response changeRoleStatus(@QueryParam("id") int id) {
//        try {
//            String newStatus = admin.changeRoleStatus(id);
//            return Response.ok("Status updated to: " + newStatus).build();
//        } catch (IllegalArgumentException e) {
//            return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
//        }
//    }
//     @GET
//     @Path("categories")
//     @Produces("application/json")
//     public Collection<Category> getAllCategoryes()
//     {
//         return admin.getAllCategoryes();
//     }
//    @GET
//    @Produces("application/json")
//    public String getXml() {
//        //TODO return proper representation object
//        throw new UnsupportedOperationException();
//    }

    /**
     * PUT method for updating or creating an instance of adminResources
     * @param content representation for the resource
     */
//    @PUT
//    @Consumes(MediaType.APPLICATION_XML)
//    public void putXml(String content) {
//    }
}
