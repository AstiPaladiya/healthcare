/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package com.mycompany.health.resources;

import ejb.adminLocal;
import entity.Role;

import jakarta.ejb.EJB;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.enterprise.context.RequestScoped;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import java.util.Collection;
import java.util.Date;

/**
 * REST Web Service
 *
 * @author palad
 */
@Path("main")
@RequestScoped
public class MainResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of MainResource
     */
    @EJB
    adminLocal admin;
    public MainResource() {
      
    }
    @POST
    @Path("addRole/{name}/{status}")
    public void addRole(@PathParam("name") String name, @PathParam("status") String status)
    {
       admin.addRole(name,status);
    }
    /**
     * Retrieves representation of an instance of
     * com.mycompany.health.resources.MainResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of MainResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
