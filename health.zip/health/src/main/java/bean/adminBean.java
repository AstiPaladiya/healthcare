/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package bean;

import entity.Role;
import client.adminClient;
import jakarta.inject.Named;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
//import org.glassfish.soteria.identitystores.hash.Pbkdf2PasswordHashImpl;
/**
 *
 * @author palad
 */
@Named(value = "adminBean")
@Dependent
public class adminBean implements Serializable {
    @Inject
    private adminClient admin;
   private String name;
   private String status;
    public adminBean() {
        
    }
    
    public String addRole()
    {
        try{
            admin.addRole(name,status);
            return "success";
        }catch(Exception e)
        {
            e.printStackTrace();
            return "failure";
        }
    }
    
    public String getName()
    {
        return name;
    }
    public String getStatus()
    {
        return status;
    } 
    public void setName(String name)
    {
        this.name=name;
    }
    public void setStatus(String status)
    {
        this.status=status;
    } 
}
