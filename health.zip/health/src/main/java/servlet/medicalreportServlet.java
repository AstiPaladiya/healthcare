/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.medicalreportLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author palad
 */
public class medicalreportServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private medicalreportLocal medicalBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet medicalreportServlet</title>");            
            out.println("</head>");
            out.println("<body>");
          List<MedicalReport> medical=medicalBean.getAllMedicalReports();
                
                 // Generate the HTML response to display the roles
                    out.println("<h1>All medical report</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>health record id</th><th>report name id</th><th>report type</th><th>report date</th><th>report status</th><th>summery</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (MedicalReport m : medical) {
                        out.println("<tr>");
                        out.println("<td>" + m.getId() + "</td>");
                        out.println("<td>"+m.getHealthRecordId()+"</td>");
                        out.println("<td>"+m.getReportName()+"</td>");
                        out.println("<td>" + m.getReportType() + "</td>");
                        out.println("<td>" + m.getReportDate() + "</td>");
                        out.println("<td>"+m.getReportStatus()+"</td>");
                        out.println("<td>" + m.getSummery() + "</td>");
                        out.println("<td>" + m.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
          String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter())
        {
            if("insert".equals(action))
            {
                int healthId=5;
                String reportName="specialist";
                String reportType="heart";
                Date reportDate=new SimpleDateFormat("dd-MM-yyyy").parse("29-09-2002");
                String reportStatus="danger";
                String summery="this report is danger";
                String status="Active";
                try{
                    medicalBean.addMedicalReport(healthId,reportName,reportType,reportDate,reportStatus,summery,status);
                    out.println("Added Successfuly");
                }catch(Exception eq)
                {
                    out.println("Failed insertion");
                }
            }else if("delete".equals(action))
            {
                int medicalId=Integer.parseInt(request.getParameter("medicalId"));
                try{
                    medicalBean.deleteMedicalReport(medicalId);
                    out.println("Delete Successfully");
                }catch(Exception eq)
                {
                    out.println("Deleted Failed");
                }
            }else if("update".equals(action))
            {
                      int healthId=1;
                String reportName="leg report";
                String reportType="leg";
                Date reportDate=new SimpleDateFormat("dd-MM-yyyy").parse("12-09-2002");
                String reportStatus="normal";
                String summery="this report is normal";
                String status="Block";
                int medicalId=Integer.parseInt(request.getParameter("medicalId"));
                try{
                    medicalBean.updateMedicalReport(medicalId,healthId,reportName,reportType,reportDate,reportStatus,summery,status);
                    out.println("Updated successfully");
                }catch(Exception eq)
                {
                    out.println("Failed updation");
                }
                
            }else if("displayAll".equals(action))
            {
                List<MedicalReport> medical=medicalBean.getAllMedicalReports();
                
                 // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All medical report</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>health record id</th><th>report name id</th><th>report type</th><th>report date</th><th>report status</th><th>summery</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (MedicalReport m : medical) {
                        out.println("<tr>");
                        out.println("<td>" + m.getId() + "</td>");
                        out.println("<td>"+m.getHealthRecordId()+"</td>");
                        out.println("<td>"+m.getReportName()+"</td>");
                        out.println("<td>" + m.getReportType() + "</td>");
                        out.println("<td>" + m.getReportDate() + "</td>");
                        out.println("<td>"+m.getReportStatus()+"</td>");
                        out.println("<td>" + m.getSummery() + "</td>");
                        out.println("<td>" + m.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }

        } catch (ParseException ex) {
            Logger.getLogger(medicalreportServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
