/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.blogLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
/**
 *
 * @author palad
 */
public class blogServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject 
    private blogLocal blogBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet blogServlet</title>");            
            out.println("</head>");
            out.println("<body>");
             List<Blog> blog=blogBean.getAllBlogs();
                
                 // Generate the HTML response to display the roles
                    out.println("<h1>All Roles</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>Name</th><th>description</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Blog b : blog) {
                        out.println("<tr>");
                        out.println("<td>" + b.getId() + "</td>");
                        out.println("<td>"+b.getUserId()+"</td>");
                        out.println("<td>" + b.getName() + "</td>");
                        out.println("<td>"+b.getDescription()+"</td>");
   
                        out.println("<td>" + b.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter())
        {
            if("insert".equals(action))
            {
                int userId=30;
                String name="health";
                String description="Hello Docotre";
                String status="Active";
                try{
                    blogBean.addBlog(userId,name,description,status);
                    out.println("Added Successfuly");
                }catch(Exception eq)
                {
                    out.println("Failed insertion");
                }
            }else if("delete".equals(action))
            {
                int blogId=Integer.parseInt(request.getParameter("blogId"));
                try{
                    blogBean.deleteBlog(blogId);
                    out.println("Delete Successfully");
                }catch(Exception eq)
                {
                    out.println("Deleted Failed");
                }
            }else if("update".equals(action))
            {
                int userId=30;
                String name="Heartattack";
                String description="Specialist";
                String status="Block";
                int blogId=Integer.parseInt(request.getParameter("blogId"));
                try{
                    blogBean.updateBlog(blogId,userId,name,description,status);
                    out.println("Updated successfully");
                }catch(Exception eq)
                {
                    out.println("Failed updation");
                }
                
            }else if("displayAll".equals(action))
            {
                List<Blog> blog=blogBean.getAllBlogs();
                
                 // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Roles</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>Name</th><th>description</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Blog b : blog) {
                        out.println("<tr>");
                        out.println("<td>" + b.getId() + "</td>");
                        out.println("<td>"+b.getUserId()+"</td>");
                        out.println("<td>" + b.getName() + "</td>");
                        out.println("<td>"+b.getDescription()+"</td>");
   
                        out.println("<td>" + b.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
