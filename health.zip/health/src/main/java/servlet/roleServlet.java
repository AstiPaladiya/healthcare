/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.util.*;
import ejb.roleLocal;
import entity.Role;
import jakarta.inject.Inject;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import static java.lang.System.out;


/**
 *
 * @author palad
 */
public class roleServlet extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet roleServlet</title>");            
            out.println("</head>");
            out.println("<body>");
             // Retrieve all roles using the EJB
            List<Role> roles = roleBean.getAllRoles();

            // Generate the HTML response to display the roles
            out.println("<h1>All Roles</h1>");
            out.println("<table border='1'>");
            out.println("<tr><th>ID</th><th>Name</th><th>Status</th></tr>");
            
            // Loop through the roles and display each one in a table row
            for (Role role : roles) {
                out.println("<tr>");
                out.println("<td>" + role.getId() + "</td>");
                out.println("<td>" + role.getName() + "</td>");
                out.println("<td>" + role.getStatus() + "</td>");
                out.println("</tr>");
            }
            
            out.println("</table>");

            out.println("</body>");
            out.println("</html>");
        }

    }
    
    @Inject
    private roleLocal roleBean;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         // Check the action parameter to determine if it's an add or delete request
      String action = request.getParameter("action");
        try(PrintWriter out=response.getWriter()) {
             if("insert".equals(action))
             {
                 // Static values for role name and status
                String roleName = "Admin";
                String status = "Active";

                try {
                    // Call the EJB to insert the role
                    roleBean.addRole(roleName, status);
                    out.println("<html><body><h1>Role added successfully: " + roleName + " - " + status + "</h1></body></html>");
                } catch (Exception e) {
                    out.println("<html><body><h1>Failed to add role: " + e.getMessage() + "</h1></body></html>");
                } 
             }else if("delete".equals(action))
             {
                int roleId=Integer.parseInt(request.getParameter("roleId"));
                try{
                    roleBean.deleteRole(roleId);
                     out.println("<html><body><h1>Role deleted successfully with ID: " + roleId + "</h1></body></html>");
                } catch (Exception e) {
                    out.println("<html><body><h1>Failed to delete role: " + e.getMessage() + "</h1></body></html>");
                }
                
             }else if("update".equals(action))
             {
                    int roleId=Integer.parseInt(request.getParameter("roleId"));
                     try{
                        String name="Doctor";
                        String status="Block";
                        roleBean.updateRole(roleId,name,status);
                     }catch (Exception e) {
                        out.println("<html><body><h1>Failed to delete role: " + e.getMessage() + "</h1></body></html>");
                    }
             }else if("displayAll".equalsIgnoreCase(action)) {
                 // Retrieve all roles
            // Retrieve all roles using the EJB
                    List<Role> roles = roleBean.getAllRoles();

                    // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Roles</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>Name</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Role role : roles) {
                        out.println("<tr>");
                        out.println("<td>" + role.getId() + "</td>");
                        out.println("<td>" + role.getName() + "</td>");
                        out.println("<td>" + role.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");

                
            } else {
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
             }
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);
//        String name=request.getParameter("txtName");
//        String status=request.getParameter("txtStatus");
//        roleBean.addRole("Admin","Active");
//

    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
        
    }
    

}
