/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.healthwellnessLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
import java.math.BigInteger;
/**
 *
 * @author palad
 */
public class healthwellnessServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private healthwellnessLocal healthBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet healthwellnessServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            List<HealthWellness> health=healthBean.getAllHealthWellnesss();
                
                 // Generate the HTML response to display the roles
                    out.println("<h1>All Health wellness program</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>Address</th><th>schedule</th><th>description</th><th>phone no</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (HealthWellness h : health) {
                        out.println("<tr>");
                        out.println("<td>" + h.getId() + "</td>");
                        out.println("<td>"+h.getUserId()+"</td>");
                        out.println("<td>"+h.getAddress()+"</td>");
                        out.println("<td>" + h.getSchedule() + "</td>");
                        out.println("<td>" + h.getDescription() + "</td>");
                        out.println("<td>"+h.getPhoneNo()+"</td>");
                        out.println("<td>" + h.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
          String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter())
        {
            if("insert".equals(action))
            {
                int userId=30;
                String address="surat";
                String schedule="5 to 9";
                String description="this is health program";
                BigInteger phoneNo=new BigInteger("6352778198");
                String status="Active";
                try{
                    healthBean.addHealthWellness(userId,address,schedule,description,phoneNo,status);
                    out.println("Added Successfuly");
                }catch(Exception eq)
                {
                    out.println("Failed insertion");
                }
            }else if("delete".equals(action))
            {
                int healthId=Integer.parseInt(request.getParameter("healthId"));
                try{
                    healthBean.deleteHealthWellness(healthId);
                    out.println("Delete Successfully");
                }catch(Exception eq)
                {
                    out.println("Deleted Failed");
                }
            }else if("update".equals(action))
            {
                 int userId=30;
                String address="vyara";
                String schedule="2 to 9";
                String description="this is wellness program";
                BigInteger phoneNo=new BigInteger("8469892321");
                String status="Block";
                int healthId=Integer.parseInt(request.getParameter("healthId"));
                try{
                    healthBean.updateHealthWellness(healthId,userId,address,schedule,description,phoneNo,status);
                    out.println("Updated successfully");
                }catch(Exception eq)
                {
                    out.println("Failed updation");
                }
                
            }else if("displayAll".equals(action))
            {
                List<HealthWellness> health=healthBean.getAllHealthWellnesss();
                
                 // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Health wellness program</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>Address</th><th>schedule</th><th>description</th><th>phone no</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (HealthWellness h : health) {
                        out.println("<tr>");
                        out.println("<td>" + h.getId() + "</td>");
                        out.println("<td>"+h.getUserId()+"</td>");
                        out.println("<td>"+h.getAddress()+"</td>");
                        out.println("<td>" + h.getSchedule() + "</td>");
                        out.println("<td>" + h.getDescription() + "</td>");
                        out.println("<td>"+h.getPhoneNo()+"</td>");
                        out.println("<td>" + h.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
