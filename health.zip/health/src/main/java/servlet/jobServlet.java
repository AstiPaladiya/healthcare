/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import ejb.jobLocal;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
import java.math.BigInteger;
/**
 *
 * @author palad
 */
public class jobServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private jobLocal jobBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet jobServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            List<Job> job=jobBean.getAllJobs();
                
                 // Generate the HTML response to display the roles
                    out.println("<h1>All Jobs</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>career id</th><th>Name</th><th>email</th><th>phone no</th><th>resume</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Job j : job) {
                        out.println("<tr>");
                        out.println("<td>" + j.getId() + "</td>");
                        out.println("<td>"+j.getUserId()+"</td>");
                        out.println("<td>"+j.getCareerId()+"</td>");
                        out.println("<td>" + j.getName() + "</td>");
                        out.println("<td>" + j.getEmail() + "</td>");
                        out.println("<td>"+j.getPhoneNo()+"</td>");
                        out.println("<td>" + j.getResume() + "</td>");
                        out.println("<td>" + j.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
          String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter())
        {
            if("insert".equals(action))
            {
                int userId=30;
                int careerId=2;
                String name="specialist";
                String email="vimala@gmail.com";
                BigInteger phoneNo=new BigInteger("6352778198");
                String resume="resume.pdf";
                String status="Active";
                try{
                    jobBean.addJob(userId,careerId,name,email,phoneNo,resume,status);
                    out.println("Added Successfuly");
                }catch(Exception eq)
                {
                    out.println("Failed insertion");
                }
            }else if("delete".equals(action))
            {
                int jobId=Integer.parseInt(request.getParameter("jobId"));
                try{
                    jobBean.deleteJob(jobId);
                    out.println("Delete Successfully");
                }catch(Exception eq)
                {
                    out.println("Deleted Failed");
                }
            }else if("update".equals(action))
            {
                 int userId=30;
                int careerId=6;
                String name="Nusing";
                String email="mala@gmail.com";
                BigInteger phoneNo=new BigInteger("738299283");
                String resume="resume2.pdf";
                String status="Block";
                int jobId=Integer.parseInt(request.getParameter("jobId"));
                try{
                    jobBean.updateJob(jobId,userId,careerId,name,email,phoneNo,resume,status);
                    out.println("Updated successfully");
                }catch(Exception eq)
                {
                    out.println("Failed updation");
                }
                
            }else if("displayAll".equals(action))
            {
                List<Job> job=jobBean.getAllJobs();
                
                 // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Jobs</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>career id</th><th>Name</th><th>email</th><th>phone no</th><th>resume</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Job j : job) {
                        out.println("<tr>");
                        out.println("<td>" + j.getId() + "</td>");
                        out.println("<td>"+j.getUserId()+"</td>");
                        out.println("<td>"+j.getCareerId()+"</td>");
                        out.println("<td>" + j.getName() + "</td>");
                        out.println("<td>" + j.getEmail() + "</td>");
                        out.println("<td>"+j.getPhoneNo()+"</td>");
                        out.println("<td>" + j.getResume() + "</td>");
                        out.println("<td>" + j.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }

        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
