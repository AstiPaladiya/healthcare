/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.checkupbookingLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
import java.math.BigInteger;
/**
 *
 * @author palad
 */
public class checkupbookingServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private checkupbookingLocal checkupBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet checkupbookingServlet</title>");            
            out.println("</head>");
            out.println("<body>");
             List<CheckupBooking> checkup=checkupBean.getAllCheckupBookings();
                
                 // Generate the HTML response to display the roles
                    out.println("<h1>All checkup booking</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>bussiness id</th><th>schedule</th><th>price</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (CheckupBooking c : checkup) {
                        out.println("<tr>");
                        out.println("<td>" + c.getId() + "</td>");
                        out.println("<td>"+c.getUserId()+"</td>");
                        out.println("<td>" + c.getBussinessId() + "</td>");
                        out.println("<td>" + c.getSchedule() + "</td>");
                        out.println("<td>"+c.getPrice()+"</td>");
                        out.println("<td>" + c.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
          String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter())
        {
            if("insert".equals(action))
            {
                int userId=30;
                int bussinessId=30;
                String schedule="8 to 20";
                float price=(float) 120.00;
                String status="Active";
                try{
                    checkupBean.addCheckupBooking(userId,bussinessId,schedule,price,status);
                    out.println("Added Successfuly");
                }catch(Exception eq)
                {
                    out.println("Failed insertion");
                }
            }else if("delete".equals(action))
            {
                int checkupId=Integer.parseInt(request.getParameter("checkupId"));
                try{
                    checkupBean.deleteCheckupBooking(checkupId);
                    out.println("Delete Successfully");
                }catch(Exception eq)
                {
                    out.println("Deleted Failed");
                }
            }else if("update".equals(action))
            {
                     int userId=30;
                int bussinessId=30;
                String schedule="9 to 10";
                float price=(float) 220.00;
                String status="Block";
                int checkupId=Integer.parseInt(request.getParameter("checkupId"));
                try{
                    checkupBean.updateCheckupBooking(checkupId,userId,bussinessId,schedule,price,status);
                    out.println("Updated successfully");
                }catch(Exception eq)
                {
                    out.println("Failed updation");
                }
                
            }else if("displayAll".equals(action))
            {
                List<CheckupBooking> checkup=checkupBean.getAllCheckupBookings();
                
                 // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All checkup booking</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>bussiness id</th><th>schedule</th><th>price</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (CheckupBooking c : checkup) {
                        out.println("<tr>");
                        out.println("<td>" + c.getId() + "</td>");
                        out.println("<td>"+c.getUserId()+"</td>");
                        out.println("<td>" + c.getBussinessId() + "</td>");
                        out.println("<td>" + c.getSchedule() + "</td>");
                        out.println("<td>"+c.getPrice()+"</td>");
                        out.println("<td>" + c.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }

        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
