/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.subscriptionLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
/**
 *
 * @author palad
 */
public class subscriptionServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private subscriptionLocal subscriptionBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet subscriptionServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            List<Subscription> subscription = subscriptionBean.getAllSubscriptions();

                    // Generate the HTML response to display the roles
                    out.println("<h1>All Subscription</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>Id</th><th>Plan name</th><th>Plan detail</th><th>Price</th><th>Time period</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Subscription s : subscription) {
                        out.println("<tr>");
                        out.println("<td>" + s.getId() + "</td>");
                        out.println("<td>" + s.getPlanName() + "</td>");
                        out.println("<td>" + s.getPlanDetail() + "</td>");
                        out.println("<td>" + s.getPrice() + "</td>");
                        out.println("<td>" + s.getTimePeriod()+ "</td>");
                        out.println("<td>" + s.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String action=request.getParameter("action");

        try(PrintWriter out=response.getWriter()){
            if("insert".equals(action))
            {
                String plan_name="Silver Plan";
                String plan_detail="This is silver plan";
                float price=(float)200.90;
                int time_period=299;
                String status="Active";
                try{
                    subscriptionBean.addSubscription(plan_name,plan_detail,price,time_period,status);
                    out.println("Added successfuly");
                }catch(Exception eq)
                {
                    out.println("Faild insertion");
                }
            }else if("delete".equals(action))
            {
                int subscriptionId=Integer.parseInt(request.getParameter("subscriptionId"));
                try{
                    subscriptionBean.deleteSubscription(subscriptionId);
                    out.println("update successfuly");
                }catch(Exception eq)
                {   
                    out.println("Deletion failed");
                }
            }else if("update".equals(action))
            {
                int subscriptionId=Integer.parseInt(request.getParameter("subscriptionId"));
                try{
                     String plan_name="Golden Plan";
                    String plan_detail="This is Golden plan";
                    float price=(float)100.90;
                    int time_period=199;
                    String status="Block";
                    subscriptionBean.updateSubscription(subscriptionId,plan_name,plan_detail,price,time_period,status);
                    out.println("updated successfuly");
                }catch(Exception eq)
                {   
                    out.println("updated failed");
                }
            }else if("displayAll".equalsIgnoreCase(action)) {
                 // Retrieve all roles
            // Retrieve all roles using the EJB
                    List<Subscription> subscription = subscriptionBean.getAllSubscriptions();

                    // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Roles</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>Id</th><th>Plan name</th><th>Plan detail</th><th>Price</th><th>Time period</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Subscription s : subscription) {
                        out.println("<tr>");
                        out.println("<td>" + s.getId() + "</td>");
                        out.println("<td>" + s.getPlanName() + "</td>");
                        out.println("<td>" + s.getPlanDetail() + "</td>");
                        out.println("<td>" + s.getPrice() + "</td>");
                        out.println("<td>" + s.getTimePeriod()+ "</td>");
                        out.println("<td>" + s.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");

                
            } else {
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
             }
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
