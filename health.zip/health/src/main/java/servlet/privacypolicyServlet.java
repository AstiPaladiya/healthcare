/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.privacypolicyLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
/**
 *
 * @author palad
 */
public class privacypolicyServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private privacypolicyLocal privacyBean;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet privacypolicyServlet</title>");            
            out.println("</head>");
            out.println("<body>");
             // Retrieve all roles using the EJB
                    List<PrivacyPolicy> privacy = privacyBean.getAllPrivacyPolicys();

                    // Generate the HTML response to display the roles
                    out.println("<h1>All Privacy & policy</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>Name</th><th>Description</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (PrivacyPolicy p : privacy) {
                        out.println("<tr>");
                        out.println("<td>" + p.getId() + "</td>");
                        out.println("<td>" + p.getName() + "</td>");
                        out.println("<td>" + p.getDescription() + "</td>");
                        out.println("<td>" + p.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter()){
            if("insert".equals(action))
            {
                String name="privacy";
                String description="This is privacy";
                String status="Active";
                try{
                    privacyBean.addPrivacyPolicy(name,description,status);
                    out.println("insertion successfully");
                }
                catch(Exception eq)
                {
                    out.println("Failed insertion");
                }    
            }else if("delete".equals(action))
            {
                int privacyId=Integer.parseInt(request.getParameter("privacyId"));
                try{
                    privacyBean.deletePrivacyPolicy(privacyId);
                     out.println("deletion successfully");
                }catch(Exception eq)
                {
                     out.println("Failed deletion");
                }
            }else if("update".equals(action))
            {
                int privacyId=Integer.parseInt(request.getParameter("privacyId"));
                try{
                    String name="policy";
                    String description="This is policy";
                    String status="Block";
                    privacyBean.updatePrivacyPolicy(privacyId,name,description,status);
                     out.println("updation successfully");
                }catch(Exception eq)
                {
                     out.println("Failed updation");
                }
            }else if("displayAll".equalsIgnoreCase(action)) {
                 // Retrieve all roles
            // Retrieve all roles using the EJB
                    List<PrivacyPolicy> privacy = privacyBean.getAllPrivacyPolicys();

                    // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Roles</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>Name</th><th>Description</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (PrivacyPolicy p : privacy) {
                        out.println("<tr>");
                        out.println("<td>" + p.getId() + "</td>");
                        out.println("<td>" + p.getName() + "</td>");
                        out.println("<td>" + p.getDescription() + "</td>");
                        out.println("<td>" + p.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            }
            else {
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
             }
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
