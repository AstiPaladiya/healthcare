/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.productLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author palad
 */
public class productServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private productLocal productBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet productServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            List<Product> product=productBean.getAllProducts();
                
                                    // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Users</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr>"
                        + "<th>ID</th>"
                        + "<th>User ID</th>"
                        + "<th>category ID</th>"
                        + "<th>Email</th>"
                        + "<th>company Name</th>"
                        + "<th>prescription </th>"
                        + "<th>medicine Name</th>"
                        + "<th>Description</th>"
                        + "<th>price</th>"
                        + "<th>image1</th>"
                        + "<th>image2</th>"
                        + "<th>imag3</th>"
                        + "<th>imag4</th>"
                        + "<th>quantity</th>"
                        + "<th>Product status</th>"
                        + "<th>blocked by</th>"
                       
                        + "</tr>");

                    // Loop through the users and display each one in a table row
                    for (Product p : product) {
                        out.println("<tr>");
                        out.println("<td>" + p.getId() + "</td>");
                        out.println("<td>" + p.getUserId() + "</td>");
                        out.println("<td>" + p.getCategoryId() + "</td>");
                        out.println("<td>" + p.getCompanyName() + "</td>");
                        out.println("<td>" + p.getPrescription() + "</td>");
                        out.println("<td>" + p.getMedicineName() + "</td>");
                        out.println("<td>" + p.getDescription() + "</td>");
                        out.println("<td>" + p.getImg1() + "</td>");
                        out.println("<td>" + p.getImg2() + "</td>");
                        out.println("<td>" + p.getImg3() + "</td>");
                        out.println("<td>" + p.getImg4() + "</td>");
                        out.println("<td>" + p.getQuantity() + "</td>");
                        out.println("<td>" + p.getAvailableQuantity() + "</td>");
                        out.println("<td>" + p.getOffer() + "</td>");
                        out.println("<td>" + p.getProductStatus() + "</td>");
                        out.println("<td>" + p.getBlockedBy() + "</td>");
                       
                        out.println("</tr>");
                    }

                    out.println("</table></body></html>");

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
          String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter()){
             if("insert".equals(action))
             {
                 int categoryId=2;
                 int userId=30;
                 String companyName="himalaya";
                 String prescription="himoglobin";
                 String medicineName="sirum";
                 String description="this is  sirum medicine";
                 float price=(float)120.90;
                 String img1="photo1.jpg";
                 String img2="photo2.jpg";
                 String img3="photo3.jpg";
                 String img4="photo4.jpg";
                 int quantity=20;
                 int availableQuantity=20;
                 float offer=(float)20;
                 String productStatus="Active";
                 int blockedBy=30;
                 try{
                     productBean.addProduct(categoryId,userId,companyName,prescription,medicineName,description,price,img1,img2,img3,img4,quantity,availableQuantity,offer,productStatus,blockedBy);
                     out.println("Inserted succesfully");
                 }catch(Exception eq)
                 {
                     out.println("failed insertion");
                 }
             }else if("delete".equals(action))
             {
                 int productId=Integer.parseInt(request.getParameter("productId"));
                 try{
                     productBean.deleteProduct(productId);
                     out.println("Delete successfully");
                 }catch(Exception eq)
                 {
                     out.println("failed  deletion");
                 }    
             }else if("update".equals(action))
             {
                 int productId=Integer.parseInt(request.getParameter("productId"));
                 int categoryId=4;
                 int userId=30;
                 String companyName="lekmi";
                 String prescription="monopoly";
                 String medicineName="cupsiup";
                 String description="this is   medicine";
                 float price=(float)820.90;
                 String img1="photo9.jpg";
                 String img2="photo8.jpg";
                 String img3="photo6.jpg";
                 String img4="photo5.jpg";
                 int quantity=60;
                 int availableQuantity=40;
                 float offer=(float)20;
                 String productStatus="Block";
                 int blockedBy=30;
                 try{
                     productBean.updateProduct(productId,categoryId,userId,companyName,prescription,medicineName,description,price,img1,img2,img3,img4,quantity,availableQuantity,offer,productStatus,blockedBy);
                     out.println("Inserted succesfully");
                 }catch(Exception eq)
                 {
                     out.println("failed  updateion");
                 }
              }else if("displayAll".equals(action))
              {
                List<Product> product=productBean.getAllProducts();
                
                                    // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Users</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr>"
                        + "<th>ID</th>"
                        + "<th>User ID</th>"
                        + "<th>category ID</th>"
                        + "<th>Email</th>"
                        + "<th>company Name</th>"
                        + "<th>prescription </th>"
                        + "<th>medicine Name</th>"
                        + "<th>Description</th>"
                        + "<th>price</th>"
                        + "<th>image1</th>"
                        + "<th>image2</th>"
                        + "<th>imag3</th>"
                        + "<th>imag4</th>"
                        + "<th>quantity</th>"
                        + "<th>Product status</th>"
                        + "<th>blocked by</th>"
                       
                        + "</tr>");

                    // Loop through the users and display each one in a table row
                    for (Product p : product) {
                        out.println("<tr>");
                        out.println("<td>" + p.getId() + "</td>");
                        out.println("<td>" + p.getUserId() + "</td>");
                        out.println("<td>" + p.getCategoryId() + "</td>");
                        out.println("<td>" + p.getCompanyName() + "</td>");
                        out.println("<td>" + p.getPrescription() + "</td>");
                        out.println("<td>" + p.getMedicineName() + "</td>");
                        out.println("<td>" + p.getDescription() + "</td>");
                        out.println("<td>" + p.getImg1() + "</td>");
                        out.println("<td>" + p.getImg2() + "</td>");
                        out.println("<td>" + p.getImg3() + "</td>");
                        out.println("<td>" + p.getImg4() + "</td>");
                        out.println("<td>" + p.getQuantity() + "</td>");
                        out.println("<td>" + p.getAvailableQuantity() + "</td>");
                        out.println("<td>" + p.getOffer() + "</td>");
                        out.println("<td>" + p.getProductStatus() + "</td>");
                        out.println("<td>" + p.getBlockedBy() + "</td>");
                       
                        out.println("</tr>");
                    }

                    out.println("</table></body></html>");

            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }
        }
    }   

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
