/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.healthrecordLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
import java.math.BigInteger;
/**
 *
 * @author palad
 */
public class healthrecordServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private healthrecordLocal healthrecordBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet healthrecordServlet</title>");            
            out.println("</head>");
            out.println("<body>");
           List<HealthRecord> healthrecord=healthrecordBean.getAllHealthRecords();
                
                 // Generate the HTML response to display the roles
                    out.println("<h1>All health record</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>book id</th><th>information</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (HealthRecord h : healthrecord) {
                        out.println("<tr>");
                        out.println("<td>" + h.getId() + "</td>");
                        out.println("<td>"+h.getBookId()+"</td>");
                        out.println("<td>" + h.getInformation() + "</td>");
                        out.println("<td>" + h.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
           String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter())
        {
            if("insert".equals(action))
            {
                int bookId=4;
                String information="this is health report";
                String status="Active";
                try{
                    healthrecordBean.addHealthRecord(bookId,information,status);
                    out.println("Added Successfuly");
                }catch(Exception eq)
                {
                    out.println("Failed insertion");
                }
            }else if("delete".equals(action))
            {
                int healthrecordId=Integer.parseInt(request.getParameter("healthrecordId"));
                try{
                    healthrecordBean.deleteHealthRecord(healthrecordId);
                    out.println("Delete Successfully");
                }catch(Exception eq)
                {
                    out.println("Deleted Failed");
                }
            }else if("update".equals(action))
            {
                 int bookId=2;
                String information="this is  report";
                String status="Block";
                int healthrecordId=Integer.parseInt(request.getParameter("healthrecordId"));
                try{
                    healthrecordBean.updateHealthRecord(healthrecordId,bookId,information,status);
                    out.println("Updated successfully");
                }catch(Exception eq)
                {
                    out.println("Failed updation");
                }
                
            }else if("displayAll".equals(action))
            {
                List<HealthRecord> healthrecord=healthrecordBean.getAllHealthRecords();
                
                 // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All health record</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>book id</th><th>information</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (HealthRecord h : healthrecord) {
                        out.println("<tr>");
                        out.println("<td>" + h.getId() + "</td>");
                        out.println("<td>"+h.getBookId()+"</td>");
                        out.println("<td>" + h.getInformation() + "</td>");
                        out.println("<td>" + h.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }

        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
