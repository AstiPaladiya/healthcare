/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.careerLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
/**
 *
 * @author palad
 */
public class careerServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private careerLocal careerBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet careerServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            List<Career> career=careerBean.getAllCareers();
                
                 // Generate the HTML response to display the roles
                    out.println("<h1>All Roles</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>Name</th><th>Time</th><th>description</th><th>experience</th><th>degree</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Career c : career) {
                        out.println("<tr>");
                        out.println("<td>" + c.getId() + "</td>");
                        out.println("<td>"+c.getUserId()+"</td>");
                        out.println("<td>" + c.getCarrerName() + "</td>");
                        out.println("<td>" + c.getTime() + "</td>");
                        out.println("<td>"+c.getDescription()+"</td>");
                        out.println("<td>" + c.getExperience() + "</td>");
                        out.println("<td>" + c.getDegree() + "</td>");
                        out.println("<td>" + c.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
          String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter())
        {
            if("insert".equals(action))
            {
                int userId=30;
                String careername="health";
                String time="8 to 10";
                String description="Hello Docotre";
                String experience="2 year";
                String degree="M.D.";
                String status="Active";
                try{
                    careerBean.addCareer(userId,careername,time,description,experience,degree,status);
                    out.println("Added Successfuly");
                }catch(Exception eq)
                {
                    out.println("Failed insertion");
                }
            }else if("delete".equals(action))
            {
                int careerId=Integer.parseInt(request.getParameter("careerId"));
                try{
                    careerBean.deleteCareer(careerId);
                    out.println("Delete Successfully");
                }catch(Exception eq)
                {
                    out.println("Deleted Failed");
                }
            }else if("update".equals(action))
            {
                 int userId=30;
                String careername="wellness";
                String time="8 to 10";
                String description="Hello nurse";
                String experience="1 year";
                String degree="M.S.";
                String status="Block";
                int careerId=Integer.parseInt(request.getParameter("careerId"));
                try{
                    careerBean.updateCareer(careerId,userId,careername,time,description,experience,degree,status);
                    out.println("Updated successfully");
                }catch(Exception eq)
                {
                    out.println("Failed updation");
                }
                
            }else if("displayAll".equals(action))
            {
                List<Career> career=careerBean.getAllCareers();
                
                 // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All career</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>user id</th><th>Name</th><th>Time</th><th>description</th><th>experience</th><th>degree</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Career c : career) {
                        out.println("<tr>");
                        out.println("<td>" + c.getId() + "</td>");
                        out.println("<td>"+c.getUserId()+"</td>");
                        out.println("<td>" + c.getCarrerName() + "</td>");
                        out.println("<td>" + c.getTime() + "</td>");
                        out.println("<td>"+c.getDescription()+"</td>");
                        out.println("<td>" + c.getExperience() + "</td>");
                        out.println("<td>" + c.getDegree() + "</td>");
                        out.println("<td>" + c.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }

        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
