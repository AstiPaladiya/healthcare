/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.userLocal;
import entity.Role;
import entity.Subscription;
import entity.User;
import jakarta.inject.Inject;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Date;

/**
 *
 * @author palad
 */
public class userServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Inject
    private userLocal userBean;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet userServlet</title>");            
            out.println("</head>");
            out.println("<body>");
           List<User> user=userBean.getAllUsers();
                
                                    // Generate the HTML response to display the roles
                    out.println("<h1>All Users</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr>"
                        + "<th>ID</th>"
                        + "<th>Role ID</th>"
                        + "<th>Subscription ID</th>"
                        + "<th>Email</th>"
                        + "<th>First Name</th>"
                        + "<th>Last Name</th>"
                        + "<th>Phone Number</th>"
                        + "<th>Date of Birth</th>"
                        + "<th>Gender</th>"
                        + "<th>Address</th>"
                        + "<th>Emergency Number</th>"
                        + "<th>Profile</th>"
                        + "<th>Pincode</th>"
                        + "<th>State</th>"
                        + "<th>City</th>"
                        + "<th>Specialization</th>"
                        + "<th>Medical License</th>"
                        + "<th>Years of Experience</th>"
                        + "<th>Degree</th>"
                        + "<th>Certification</th>"
                        + "<th>Affiliate Hospital</th>"
                        + "<th>Current Position</th>"
                        + "<th>Work Schedule</th>"
                        + "<th>Registration Date</th>"
                        + "<th>Bio</th>"
                        + "<th>Hospital Name</th>"
                        + "<th>Website</th>"
                        + "<th>Expiry Date</th>"
                        + "<th>MAC Address</th>"
                        + "<th>Status</th>"
                        + "</tr>");

                    // Loop through the users and display each one in a table row
                    for (User u : user) {
                        out.println("<tr>");
                        out.println("<td>" + u.getId() + "</td>");
                        out.println("<td>" + u.getRoleId() + "</td>");
                        out.println("<td>" + u.getSubscriptionId() + "</td>");
                        out.println("<td>" + u.getEmail() + "</td>");
                        out.println("<td>" + u.getFirstName() + "</td>");
                        out.println("<td>" + u.getLastName() + "</td>");
                        out.println("<td>" + u.getPhoneNo() + "</td>");
                        out.println("<td>" + u.getDateOfBirth() + "</td>");
                        out.println("<td>" + u.getGender() + "</td>");
                        out.println("<td>" + u.getAddress() + "</td>");
                        out.println("<td>" + u.getEmergencyNo() + "</td>");
                        out.println("<td>" + u.getProfile() + "</td>");
                        out.println("<td>" + u.getPincode() + "</td>");
                        out.println("<td>" + u.getState() + "</td>");
                        out.println("<td>" + u.getCity() + "</td>");
                        out.println("<td>" + u.getSpecialization() + "</td>");
                        out.println("<td>" + u.getMedicalLicense() + "</td>");
                        out.println("<td>" + u.getYearOfExpirence() + "</td>");
                        out.println("<td>" + u.getDegree() + "</td>");
                        out.println("<td>" + u.getCertification() + "</td>");
                        out.println("<td>" + u.getAffiliateHospital() + "</td>");
                        out.println("<td>" + u.getCurrentPosition() + "</td>");
                        out.println("<td>" + u.getWorkSchedule() + "</td>");
                        out.println("<td>" + u.getRegistrationDate() + "</td>");
                        out.println("<td>" + u.getBio() + "</td>");
                        out.println("<td>" + u.getHospitalName() + "</td>");
                        out.println("<td>" + u.getWebsite() + "</td>");
                        out.println("<td>" + u.getExpiaryDate() + "</td>");
                        out.println("<td>" + u.getMacAddress() + "</td>");
                        out.println("<td>" + u.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table></body></html>");

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter()){
             if("insert".equals(action))
             {
                 int roleId=7;
                 int subscriptionId=3;
                 String email="paladiyaasti@gmail.com";
                 String firstName="Asti";
                 String lastName="Paladiya";
                 String password="Asti";
                 BigInteger phoneNo = new BigInteger("6352778198"); 
                 Date dateOfBirth=new SimpleDateFormat("dd-MM-yyyy").parse("25-09-2002");
                 String gender="23 year";
                 String address="42,shree ramanager";
                 BigInteger emergencyNo=new BigInteger("8469895145");
                 String profile="img4.jpg";
                 int pincode=395006;
                 String state="Gujarat";
                 String city="Surat";
                 String specialization="Student";
                 String medicalLicense="APZx234";
                 String yearExperience="2 year";
                 String degree="M.B.B.S";
                 String certificate="img5.jpg";
                 String affiliateHospital="xyz";
                 String currentPosition="Student";
                 String workSchedule="8am";
                 Date registrationDate=new SimpleDateFormat("dd-MM-yyyy").parse("8-08-1978");
                 String bio="I am doctor";
                 String hospitalName="ABC";
                 String website="careQ";
                 Date expiarydate=new SimpleDateFormat("dd-MM-yyyy").parse("13-11-2002");
                 String macAddress="absc233";
                 String status="Active";
                 try{
                     userBean.addUser(roleId,subscriptionId,email,firstName,lastName,password,phoneNo,dateOfBirth,gender,address,emergencyNo,profile,pincode,state,city,specialization,medicalLicense,yearExperience,degree,certificate,affiliateHospital,currentPosition,workSchedule,registrationDate,bio,hospitalName,website,expiarydate,macAddress,status);
                     out.println("Inserted succesfully");
                 }catch(Exception eq)
                 {
                     out.println("failed insertion");
                 }
             }else if("delete".equals(action))
             {
                 int userId=Integer.parseInt(request.getParameter("userId"));
                 try{
                     userBean.deleteUser(userId);
                     out.println("Delete successfully");
                 }catch(Exception eq)
                 {
                     out.println("failed  deletion");
                 }    
             }else if("update".equals(action))
             {
                 int userId=Integer.parseInt(request.getParameter("userId"));
                try{
                    int roleId=4;
                    int subscriptionId=5;
                    String email="diya@gmail.com";
                    String firstName="diya";
                    String lastName="Pancha;";
                    String password="Asti";
                    BigInteger phoneNo = new BigInteger("7828479339"); 
                    Date dateOfBirth=new SimpleDateFormat("dd-MM-yyyy").parse("25-09-2002");
                    String gender="23 year";
                    String address="42,shree ramanager";
                    BigInteger emergencyNo=new BigInteger("8469895145");
                    String profile="img4.jpg";
                    int pincode=395006;
                    String state="Gujarat";
                    String city="Vyara";
                    String specialization="Student";
                    String medicalLicense="APZx234";
                    String yearExperience="2 year";
                    String degree="M.D";
                    String certificate="img6.jpg";
                    String affiliateHospital="xyz";
                    String currentPosition="Student";
                    String workSchedule="8am";
                    Date registrationDate=new SimpleDateFormat("dd-MM-yyyy").parse("8-08-1978");
                    String bio="I am Nurse";
                    String hospitalName="ABC";
                    String website="careQ";
                    Date expiarydate=new SimpleDateFormat("dd-MM-yyyy").parse("13-11-2002");
                    String macAddress="absc233";
                    String status="Block";
                    try{
                        userBean.updateUser(userId,roleId,subscriptionId,email,firstName,lastName,password,phoneNo,dateOfBirth,gender,address,emergencyNo,profile,pincode,state,city,specialization,medicalLicense,yearExperience,degree,certificate,affiliateHospital,currentPosition,workSchedule,registrationDate,bio,hospitalName,website,expiarydate,macAddress,status);
                        out.println("Inserted succesfully");
                    }catch(Exception eq)
                    {
                        out.println("failed  updateion");
                    }  
                }   catch (ParseException ex) {
                     Logger.getLogger(userServlet.class.getName()).log(Level.SEVERE, null, ex);
                 }
              }else if("displayAll".equals(action))
              {
                List<User> user=userBean.getAllUsers();
                
                                    // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Users</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr>"
                        + "<th>ID</th>"
                        + "<th>Role ID</th>"
                        + "<th>Subscription ID</th>"
                        + "<th>Email</th>"
                        + "<th>First Name</th>"
                        + "<th>Last Name</th>"
                        + "<th>Phone Number</th>"
                        + "<th>Date of Birth</th>"
                        + "<th>Gender</th>"
                        + "<th>Address</th>"
                        + "<th>Emergency Number</th>"
                        + "<th>Profile</th>"
                        + "<th>Pincode</th>"
                        + "<th>State</th>"
                        + "<th>City</th>"
                        + "<th>Specialization</th>"
                        + "<th>Medical License</th>"
                        + "<th>Years of Experience</th>"
                        + "<th>Degree</th>"
                        + "<th>Certification</th>"
                        + "<th>Affiliate Hospital</th>"
                        + "<th>Current Position</th>"
                        + "<th>Work Schedule</th>"
                        + "<th>Registration Date</th>"
                        + "<th>Bio</th>"
                        + "<th>Hospital Name</th>"
                        + "<th>Website</th>"
                        + "<th>Expiry Date</th>"
                        + "<th>MAC Address</th>"
                        + "<th>Status</th>"
                        + "</tr>");

                    // Loop through the users and display each one in a table row
                    for (User u : user) {
                        out.println("<tr>");
                        out.println("<td>" + u.getId() + "</td>");
                        out.println("<td>" + u.getRoleId() + "</td>");
                        out.println("<td>" + u.getSubscriptionId() + "</td>");
                        out.println("<td>" + u.getEmail() + "</td>");
                        out.println("<td>" + u.getFirstName() + "</td>");
                        out.println("<td>" + u.getLastName() + "</td>");
                        out.println("<td>" + u.getPhoneNo() + "</td>");
                        out.println("<td>" + u.getDateOfBirth() + "</td>");
                        out.println("<td>" + u.getGender() + "</td>");
                        out.println("<td>" + u.getAddress() + "</td>");
                        out.println("<td>" + u.getEmergencyNo() + "</td>");
                        out.println("<td>" + u.getProfile() + "</td>");
                        out.println("<td>" + u.getPincode() + "</td>");
                        out.println("<td>" + u.getState() + "</td>");
                        out.println("<td>" + u.getCity() + "</td>");
                        out.println("<td>" + u.getSpecialization() + "</td>");
                        out.println("<td>" + u.getMedicalLicense() + "</td>");
                        out.println("<td>" + u.getYearOfExpirence() + "</td>");
                        out.println("<td>" + u.getDegree() + "</td>");
                        out.println("<td>" + u.getCertification() + "</td>");
                        out.println("<td>" + u.getAffiliateHospital() + "</td>");
                        out.println("<td>" + u.getCurrentPosition() + "</td>");
                        out.println("<td>" + u.getWorkSchedule() + "</td>");
                        out.println("<td>" + u.getRegistrationDate() + "</td>");
                        out.println("<td>" + u.getBio() + "</td>");
                        out.println("<td>" + u.getHospitalName() + "</td>");
                        out.println("<td>" + u.getWebsite() + "</td>");
                        out.println("<td>" + u.getExpiaryDate() + "</td>");
                        out.println("<td>" + u.getMacAddress() + "</td>");
                        out.println("<td>" + u.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table></body></html>");

            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }
        } catch (ParseException ex) {
            Logger.getLogger(userServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        /* }   catch (ParseException ex) {
        Logger.getLogger(userServlet.class.getName()).log(Level.SEVERE, null, ex);
        }*/
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
