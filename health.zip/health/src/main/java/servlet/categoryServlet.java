/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import ejb.categoryLocal;
import entity.*;
import jakarta.inject.Inject;
import static java.lang.System.out;
/**
 *
 * @author palad
 */
public class categoryServlet extends HttpServlet {
    @Inject
    private categoryLocal categoryBean;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet categoryServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            List<Category> category=categoryBean.getAllCategoryes();
                
                 // Generate the HTML response to display the roles
                    out.println("<h1>All Category</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>Role id</th><th>Name</th><th>description</th><th>image</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Category c : category) {
                        out.println("<tr>");
                        out.println("<td>" + c.getId() + "</td>");
                        out.println("<td>"+c.getRoleId()+"</td>");
                        out.println("<td>" + c.getName() + "</td>");
                        out.println("<td>"+c.getDescription()+"</td>");
                        out.println("<td>"+c.getImage()+"</td>");
                        out.println("<td>" + c.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                   
            out.println("</body>");
            out.println("</html>");
        }
    }

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        String action=request.getParameter("action");
        try(PrintWriter out=response.getWriter())
        {
            if("insert".equals(action))
            {
                int roleId=10;
                String name="Operation";
                String description="Hello Docotre";
                String image="img1.jpg";
                String status="Active";
                try{
                    categoryBean.addCategory(roleId,name,description,image,status);
                    out.println("Added Successfuly");
                }catch(Exception eq)
                {
                    out.println("Failed insertion");
                }
            }else if("delete".equals(action))
            {
                int categoryId=Integer.parseInt(request.getParameter("categoryId"));
                try{
                    categoryBean.deleteCategory(categoryId);
                    out.println("Delete Successfully");
                }catch(Exception eq)
                {
                    out.println("Deleted Failed");
                }
            }else if("update".equals(action))
            {
                int roleId=13;
                String name="Heartattack";
                String description="Specialist";
                String image="image2.jpg";
                String status="Block";
                int categoryId=Integer.parseInt(request.getParameter("categoryId"));
                try{
                    categoryBean.updateCategory(categoryId,roleId,name,description,image,status);
                    out.println("Updated successfully");
                }catch(Exception eq)
                {
                    out.println("Failed updation");
                }
                
            }else if("displayAll".equals(action))
            {
                List<Category> category=categoryBean.getAllCategoryes();
                
                 // Generate the HTML response to display the roles
                    out.println("<html><body><h1>All Roles</h1>");
                    out.println("<table border='1'>");
                    out.println("<tr><th>ID</th><th>Role id</th><th>Name</th><th>description</th><th>image</th><th>Status</th></tr>");

                    // Loop through the roles and display each one in a table row
                    for (Category c : category) {
                        out.println("<tr>");
                        out.println("<td>" + c.getId() + "</td>");
                        out.println("<td>"+c.getRoleId()+"</td>");
                        out.println("<td>" + c.getName() + "</td>");
                        out.println("<td>"+c.getDescription()+"</td>");
                        out.println("<td>"+c.getImage()+"</td>");
                        out.println("<td>" + c.getStatus() + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("</body></html>");
            
            }else{
                    out.println("<html><body><h1>Invalid action</h1></body></html>");
            }
       
    }
 }
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
