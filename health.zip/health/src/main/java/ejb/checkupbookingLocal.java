/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import entity.CheckupBooking;
import jakarta.ejb.Local;
import java.util.List;
/**
 *
 * @author palad
 */
@Local
public interface checkupbookingLocal {
        void addCheckupBooking(int userId,int bussinessId,String schedule,float price,String status);
    void deleteCheckupBooking(int checkupId);
    void updateCheckupBooking(int checkupId,int userId,int bussinessId,String schedule,float price,String status);
   List<CheckupBooking> getAllCheckupBookings();
}
