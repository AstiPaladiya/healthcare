/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.PrivacyPolicy;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Stateless
public class privacypolicy implements privacypolicyLocal {
  @PersistenceContext(unitName="health")
    EntityManager em;
  
   @Override
    public List<PrivacyPolicy> getAllPrivacyPolicys()
    {
                return em.createNamedQuery("PrivacyPolicy.findAll", PrivacyPolicy.class).getResultList();

    }
    @Override
    public void addPrivacyPolicy(String name,String description,String status)
    {
        try{
            PrivacyPolicy p=new PrivacyPolicy();
            p.setName(name);
            p.setDescription(description);
            p.setStatus(status);
            Date d=new Date();
            p.setCreatedAt(d);
            p.setUpdatedAt(d);
            em.persist(p);
            System.out.println("insertion successfully");
        }catch(Exception eq)
        {
            System.out.println("Failed insertion");
        }
    }
   @Override
    public void deletePrivacyPolicy(int privacyId)
    {
        try{
            PrivacyPolicy p=em.find(PrivacyPolicy.class,privacyId);
            if(p!=null)
            {
                em.remove(p);
                 System.out.println("deletion successfully");
            }else
            {
                System.out.println("id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed deeletion");
        }
    }
    
    @Override
    public void updatePrivacyPolicy(int privacyId,String name,String description,String status)
    {
        try{
            PrivacyPolicy p=em.find(PrivacyPolicy.class, privacyId);
            if(p!=null)
            {
                p.setName(name);
                p.setDescription(description);
                p.setStatus(status);
                p.setUpdatedAt(new Date());
                em.merge(p);
                System.out.println("updation successfully");
            }else
            {
                System.out.println("id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
    }
}
