/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.User;
import entity.Career;
import jakarta.ejb.Stateless;
import java.util.Date;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Set;

/**
 *
 * @author palad
 */
@Stateless
public class career implements careerLocal {

     @PersistenceContext(unitName="health")
    EntityManager em;
    
     @Override
     public List<Career> getAllCareers()
     {
          return em.createNamedQuery("Career.findAll",Career.class).getResultList();
//         return em.createQuery("SELECT new yourpackage.CategoryWithRoleNameDTO(c.name, c.description, c.image, c.status, r.name) " +
//                          "FROM Category c JOIN c.role r", CategoryWithRoleNameDTO.class)
//             .getResultList();
     }
     @Override
    public void addCareer(int userId,String careername,String time,String description,String experience,String degree,String status)
    {
        try{
            User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
            Career c=new Career();
            c.setUserId(u);
            c.setCarrerName(careername);
            c.setTime(time);
            c.setDescription(description);
            c.setExperience(experience);
            c.setDegree(degree);
            c.setStatus(status);
            Date currentDate=new Date();
            c.setCreatedAt(currentDate);
            c.setUpdatedAt(currentDate);
            em.persist(c);
            System.out.println("Added successfuly");
        }catch(Exception eq)
        {
            eq.printStackTrace();
            System.out.println("Failrd insertion");
        }
    }
    @Override
    public void deleteCareer(int careerId)
    {
        try{
            Career c=em.find(Career.class, careerId);
            if(c!=null)
            {
                em.remove(c);
                System.out.println("Deleted successfully");
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed Deletion");
        }
    }
      @Override
    public void updateCareer(int careerId,int userId,String careername,String time,String description,String experience,String degree,String status)
    {
        try{
             User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + userId);
            }
            Career c=em.find(Career.class, careerId);
            if(c!=null)
            {
                c.setUserId(u);
                c.setCarrerName(careername);
                c.setTime(time);
                c.setDescription(description);
                c.setExperience(experience);
                c.setDegree(degree);
                c.setStatus(status);

            c.setUpdatedAt(new Date());
                em.merge(c);
                System.out.println("updated successfuly");
                
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
        
    }
}
