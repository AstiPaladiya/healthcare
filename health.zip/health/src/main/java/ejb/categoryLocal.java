/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import jakarta.ejb.Local;
import entity.*;
import java.util.List;
/**
 *
 * @author palad
 */
@Local
public interface categoryLocal {
    void addCategory(int roleId,String name,String description,String image,String status);
    void deleteCategory(int categoryId);
    void updateCategory(int categoryId,int roleId,String name,String description,String image,String status);
    List<Category> getAllCategoryes();
}
