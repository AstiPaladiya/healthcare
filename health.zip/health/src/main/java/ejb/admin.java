/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.Role;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Stateless
public class admin implements adminLocal {
  @PersistenceContext(unitName="health")
    EntityManager em;

     @Override
    public void addRole(String name,String status)
    {
        try {
            Role r = new Role();
            r.setName(name);
            r.setStatus(status);

            Date currentDate = new Date();
            r.setCreatedAt(currentDate);
            r.setUpdatedAt(currentDate);

            em.persist(r);
            System.out.println("Role successfully added: " + r);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error adding role: " + e.getMessage());
        }
//        String insert="insert into role(name,status) values ('"+name+"','"+status+"')";
//        try{
//            Statement instmt=con.createStatement();
//            instmt.executeUpdate(insert);
//        }catch(SQLException eq)
//        {
//            eq.printStackTrace();
//        }
    }
}
