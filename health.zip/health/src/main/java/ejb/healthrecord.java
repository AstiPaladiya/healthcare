/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.HealthRecord;
import entity.CheckupBooking;
import java.util.Date;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Set;
/**
 *
 * @author palad
 */
@Stateless
public class healthrecord implements healthrecordLocal {

  @PersistenceContext(unitName="health")
    EntityManager em;
    
     @Override
     public List<HealthRecord> getAllHealthRecords()
     {
          return em.createNamedQuery("HealthRecord.findAll",HealthRecord.class).getResultList();
//         return em.createQuery("SELECT new yourpackage.CategoryWithRoleNameDTO(c.name, c.description, c.image, c.status, r.name) " +
//                          "FROM Category c JOIN c.role r", CategoryWithRoleNameDTO.class)
//             .getResultList();
     }
     @Override
    public void addHealthRecord(int bookId,String information,String status)
    {
        try{
            CheckupBooking c = em.find(CheckupBooking.class, bookId);
            if (c == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + c);
            }
          
            HealthRecord h=new HealthRecord();
            h.setBookId(c);
            h.setInformation(information);
            h.setStatus(status);
            Date currentDate=new Date();
            h.setCreatedAt(currentDate);
            h.setUpdatedAt(currentDate);
            em.persist(h);
            System.out.println("Added successfuly");
        }catch(Exception eq)
        {
            eq.printStackTrace();
            System.out.println("Failrd insertion");
        }
    }
    @Override
    public void deleteHealthRecord(int healthrecordId)
    {
        try{
            HealthRecord h=em.find(HealthRecord.class, healthrecordId);
            if(h!=null)
            {
                em.remove(h);
                System.out.println("Deleted successfully");
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed Deletion");
        }
    }
      @Override
    public void updateHealthRecord(int healthrecordId,int bookId,String information,String status)
    {
        try{
             CheckupBooking c = em.find(CheckupBooking.class, bookId);
            if (c == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + c);
            }
            HealthRecord h=em.find(HealthRecord.class, healthrecordId);
            if(h!=null)
            {
                h.setBookId(c);
                h.setInformation(information);
                h.setStatus(status);

                h.setUpdatedAt(new Date());
                em.merge(h);
                System.out.println("updated successfuly");
                
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
        
    }
}

