/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.Role;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Stateless
public class role implements roleLocal {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @PersistenceContext(unitName="health")
    EntityManager em;
//    Connection con;
//    Statement stmt;
//    String query;
//    ResultSet rs;
    
//    @PostConstruct
//    void connect()
//    {
//        try{
//            Class.forName("com.mysql.jdbc.Driver");
//            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/healthcare?useSSL=false","root","asti");
//        }catch(ClassNotFoundException ce)
//        {
//            System.out.println("Driver class not found");
//        }catch(SQLException eq)
//        {
//            System.out.println("Connecyion could not be established");
//        }
//        
//    }
  @Override
    public List<Role> getAllRoles() {
         // Use the named query with Role.class to return a list of Role entities
    return em.createNamedQuery("Role.findAll", Role.class).getResultList();
//        List<Role> roles = new ArrayList<>();
//        try {
//            var cb = em.getCriteriaBuilder();
//            var cq = cb.createQuery(Role.class);
//            var root = cq.from(Role.class);
//            cq.select(root);
//            roles = em.createQuery(cq).getResultList();
//            System.out.println("Successfully retrieved " + roles.size() + " roles.");
//        } catch (Exception e) {
//            System.err.println("An error occurred while retrieving roles: " + e.getMessage());
//        }
//        return roles;
    }
    @Override
    public void addRole(String name,String status)
    {
        try {
            Role r = new Role();
            r.setName(name);
            r.setStatus(status);

            Date currentDate = new Date();
            r.setCreatedAt(currentDate);
            r.setUpdatedAt(currentDate);

            em.persist(r);
            System.out.println("Role successfully added: " + r);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error adding role: " + e.getMessage());
        }
//        String insert="insert into role(name,status) values ('"+name+"','"+status+"')";
//        try{
//            Statement instmt=con.createStatement();
//            instmt.executeUpdate(insert);
//        }catch(SQLException eq)
//        {
//            eq.printStackTrace();
//        }
    }
     @Override
    public void deleteRole(int roleId) {
        // Find and delete the role by its ID
         try {
                Role role = em.find(Role.class, roleId);
                if (role != null) {
                    em.remove(role);
                    System.out.println("Role with ID " + roleId + " was successfully deleted.");
                } else {
                    System.out.println("Role with ID " + roleId + " not found.");
                }
            } catch (Exception e) {
                System.err.println("An unexpected error occurred: " + e.getMessage());
            }
//        String delete="delete from role where id="+roleId+"";
//        try{
//            Statement dstmt=con.createStatement();
//            dstmt.executeUpdate(delete);
//        }catch(SQLException eq){
//            eq.printStackTrace();
//        }
    }
    @Override
    public void updateRole(int roleId,String name,String status)
    {
             try {
                    Role role = em.find(Role.class, roleId);
                    if (role != null) {
                        role.setName(name);
                        role.setStatus(status);
                        role.setUpdatedAt(new Date()); // Update the timestamp
                        em.merge(role);
                        System.out.println("Role with ID " + roleId + " was successfully updated.");
                    } else {
                        System.out.println("Role with ID " + roleId + " not found.");
                    }
                }  catch (Exception e) {
                    System.err.println("An unexpected error occurred: " + e.getMessage());
                }
//        String update="update role set name='"+name+"',status='"+status+"' where id="+roleId+"";
//        try{
//            Statement ustmt=con.createStatement();
//            ustmt.executeUpdate(update);
//        }catch(SQLException eq)
//        {
//            eq.printStackTrace();
//        }
    }
}
