/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import entity.HealthWellness;
import jakarta.ejb.Local;
import java.math.BigInteger;
import java.util.List;

/**
 *
 * @author palad
 */
@Local
public interface healthwellnessLocal {
        void addHealthWellness(int userId,String address,String schedule,String description,BigInteger phoneNo,String status);
    void deleteHealthWellness(int healthId);
    void updateHealthWellness(int healthId,int userId,String address,String schedule,String description,BigInteger phoneNo,String status);
  List<HealthWellness> getAllHealthWellnesss();
}
