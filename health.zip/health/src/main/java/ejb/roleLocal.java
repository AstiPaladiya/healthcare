/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import jakarta.ejb.Local;
import entity.Role;
import java.util.List;
/**
 *
 * @author palad
 */
@Local
public interface roleLocal {
    void addRole(String name,String status);
    void deleteRole(int roleId);
    void updateRole(int roleId,String name,String status);
    List<Role> getAllRoles();
}
