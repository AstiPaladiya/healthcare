/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.Subscription;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Stateless
public class subscription implements subscriptionLocal {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @PersistenceContext(unitName="health")
    EntityManager em;
    
    @Override
    public List<Subscription> getAllSubscriptions() {
         // Use the named query with Role.class to return a list of Role entities
        return em.createNamedQuery("Subscription.findAll", Subscription.class).getResultList();
    }
    @Override
    public void addSubscription(String plan_name,String plan_detail,float price,int time_period,String status)
    {
        try{
            Subscription s=new Subscription();
            s.setPlanName(plan_name);
            s.setPlanDetail(plan_detail);
            s.setPrice(price);
            s.setTimePeriod(time_period);
            Date d=new Date();
            s.setCreatedAt(d);
            s.setUpdatedAt(d);
            s.setStatus(status);
            em.persist(s);
             System.out.println("Insertin Succsesfuly");
        }catch(Exception eq)
        {
            System.out.println("Insertin failed");
        }
    }
    
    @Override
    public void deleteSubscription(int subscriptionId)
    {
        try{
            Subscription s=em.find(Subscription.class, subscriptionId);
            if(s!=null)
            {
                em.remove(s);
                System.out.println("Deletion failed");
            }else{
                System.out.println("Id not found ");

            }
        }catch(Exception eq)
        {
            System.out.println("deletion failed");
        }  
    }
    
    @Override
    public void updateSubscription(int subscriptionId,String plan_name,String plan_detail,float price,int time_period,String status)
    {
        try{
            Subscription s=em.find(Subscription.class, subscriptionId);
            if(s!=null)
            {
                s.setPlanName(plan_name);
                s.setPlanDetail(plan_detail);
                s.setPrice(price);
                s.setTimePeriod(time_period);
                s.setUpdatedAt(new Date());
                s.setStatus(status);
                em.merge(s);
             System.out.println("Updation Succsesfuly");
            }else{
                System.out.println("Id not found ");

            }
        }catch(Exception eq)
        {
            System.out.println("updation failed");
        }  
    
    }
}
