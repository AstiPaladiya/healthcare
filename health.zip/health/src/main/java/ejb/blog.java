/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.User;
import entity.Blog;
import jakarta.ejb.Stateless;
import java.util.Date;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Set;
/**
 *
 * @author palad
 */
@Stateless
public class blog implements blogLocal {

    @PersistenceContext(unitName="health")
    EntityManager em;
    
     @Override
     public List<Blog> getAllBlogs()
     {
          return em.createNamedQuery("Blog.findAll",Blog.class).getResultList();
//         return em.createQuery("SELECT new yourpackage.CategoryWithRoleNameDTO(c.name, c.description, c.image, c.status, r.name) " +
//                          "FROM Category c JOIN c.role r", CategoryWithRoleNameDTO.class)
//             .getResultList();
     }
     @Override
    public void addBlog(int userId,String name,String description,String status)
    {
        try{
            User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
            Blog b=new Blog();
            b.setUserId(u);
            b.setName(name);
            b.setDescription(description);
            b.setStatus(status);
            Date currentDate=new Date();
            b.setCreatedAt(currentDate);
            b.setUpdatedAt(currentDate);
            em.persist(b);
            System.out.println("Added successfuly");
        }catch(Exception eq)
        {
            eq.printStackTrace();
            System.out.println("Failrd insertion");
        }
    }
     @Override
    public void deleteBlog(int blogId)
    {
        try{
            Blog b=em.find(Blog.class, blogId);
            if(b!=null)
            {
                em.remove(b);
                System.out.println("Deleted successfully");
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed Deletion");
        }
    }
      @Override
    public void updateBlog(int blogId,int userId,String name,String description,String status)
    {
        try{
             User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + userId);
            }
            Blog b=em.find(Blog.class, blogId);
            if(b!=null)
            {
                b.setUserId(u);
                b.setName(name);
                b.setDescription(description);
                b.setStatus(status);
                b.setUpdatedAt(new Date());
                em.merge(b);
                System.out.println("updated successfuly");
                
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
        
    }
}
