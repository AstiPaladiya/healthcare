/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.User;
import entity.Career;
import entity.Job;
import jakarta.ejb.Stateless;
import java.util.Date;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.math.BigInteger;
import java.util.Set;

/**
 *
 * @author palad
 */
@Stateless
public class job implements jobLocal {

    @PersistenceContext(unitName="health")
    EntityManager em;
    
     @Override
     public List<Job> getAllJobs()
     {
          return em.createNamedQuery("Job.findAll",Job.class).getResultList();
//         return em.createQuery("SELECT new yourpackage.CategoryWithRoleNameDTO(c.name, c.description, c.image, c.status, r.name) " +
//                          "FROM Category c JOIN c.role r", CategoryWithRoleNameDTO.class)
//             .getResultList();
     }
     @Override
    public void addJob(int userId,int careerId,String name,String email,BigInteger phoneNo,String resume,String status)
    {
        try{
            User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
             Career c = em.find(Career.class, careerId);
            if (c == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + c);
            }
            Job j=new Job();
            j.setUserId(u);
            j.setCareerId(c);
            j.setName(name);
            j.setEmail(email);
            j.setPhoneNo(phoneNo);
            j.setResume(resume);
            j.setStatus(status);
            Date currentDate=new Date();
            j.setCreatedAt(currentDate);
            j.setUpdatedAt(currentDate);
            em.persist(j);
            System.out.println("Added successfuly");
        }catch(Exception eq)
        {
            eq.printStackTrace();
            System.out.println("Failrd insertion");
        }
    }
    @Override
    public void deleteJob(int jobId)
    {
        try{
            Job j=em.find(Job.class, jobId);
            if(j!=null)
            {
                em.remove(j);
                System.out.println("Deleted successfully");
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed Deletion");
        }
    }
    @Override
    public void updateJob(int jobId,int userId,int careerId,String name,String email,BigInteger phoneNo,String resume,String status)
    {
        try{
             User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + userId);
            }
              Career c = em.find(Career.class, careerId);
            if (c == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + c);
            }
            Job j=em.find(Job.class, jobId);
            if(j!=null)
            {
                j.setUserId(u);
                j.setCareerId(c);
                j.setName(name);
                j.setEmail(email);
                j.setPhoneNo(phoneNo);
                j.setResume(resume);
                j.setStatus(status);
                j.setUpdatedAt(new Date());
                em.merge(j);
                System.out.println("updated successfuly");
                
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
        
    }
}
