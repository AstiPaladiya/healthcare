/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import jakarta.ejb.Local;
import entity.SubscriptionUser;
import entity.Subscription;
import entity.User;
import java.util.Date;

import java.util.List;
/**
 *
 * @author palad
 */
@Local
public interface subscriptionuserLocal {
     void addSubscriptionUser(int subscriptionId,int userId,Date expiaryDate,String paymentMode,String status);
    void deleteSubscriptionUser(int subscriptionuserId);
  void updateSubscriptionUser(int subscriptionuserId,int subscriptionId,int userId,Date expiaryDate,String paymentMode,String status);
   List<SubscriptionUser> getAllSubscriptionUsers();
}
