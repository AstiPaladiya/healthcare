/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import jakarta.ejb.Local;
import jakarta.ejb.Stateless;
import entity.Product;


import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Local
public interface productLocal {
       void addProduct(int categoryId,int userId,String companyName,String prescription,String medicineName,String description,float price,String img1,String img2,String img3,String img4,int quantity,int availableQuantity,float offer,String productStatus,int blockedBy);
   void deleteProduct(int productId);
  void updateProduct(int productId,int categoryId,int userId,String companyName,String prescription,String medicineName,String description,float price,String img1,String img2,String img3,String img4,int quantity,int availableQuantity,float offer,String productStatus,int blockedBy);
    List<Product> getAllProducts();
}
