/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.Role;
import entity.Subscription;
import entity.User;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Stateless
public class user implements userLocal {

   @PersistenceContext(unitName="health")
   EntityManager em;
   
    @Override
    public List<User> getAllUsers()
    {
                return em.createNamedQuery("User.findAll", User.class).getResultList();

    }
   @Override
   public void addUser(int roleId,int subscriptionId,String email,String firstName,String lastName,String password,BigInteger phoneNo,Date dateOfBirth,String gender,String address,BigInteger emergencyNo,String profile,int pincode,String state,String city,String specialization,String medicalLicense,String yearExperience,String degree,String certificate,String affiliateHospital,String currentPosition,String workSchedule,Date registrationDate,String bio,String hospitalName,String website,Date expiarydate,String macAddress,String status) 
   {
       try{
            Role role = em.find(Role.class, roleId);
            if (role == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + role);
            }
             Subscription subscription = em.find(Subscription.class, subscriptionId);
            if (subscription == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + subscription);
            }
           User u=new User();
           u.setRoleId(role);
           u.setSubscriptionId(subscription);
           u.setEmail(email);
           u.setFirstName(firstName);
           u.setLastName(lastName);
           u.setPassword(password);
           u.setPhoneNo(phoneNo);
           u.setDateOfBirth(dateOfBirth);
           u.setGender(gender);
           u.setAddress(address);
           u.setEmergencyNo(emergencyNo);
           u.setProfile(profile);
           u.setPincode(pincode);
           u.setState(state);
           u.setCity(city);
           u.setSpecialization(specialization);
           u.setMedicalLicense(medicalLicense);
           u.setYearOfExpirence(yearExperience);
           u.setDegree(degree);
           u.setCertification(certificate);
           u.setAffiliateHospital(affiliateHospital);
           u.setCurrentPosition(currentPosition);
           u.setWorkSchedule(workSchedule);
           u.setRegistrationDate(registrationDate);
           u.setBio(bio);
           u.setHospitalName(hospitalName);
           u.setWebsite(website);
           u.setExpiaryDate(expiarydate);
           u.setMacAddress(macAddress);
           u.setStatus(status);
           Date d=new Date();
           u.setCreatedAt(d);
           u.setUpdatedAt(d);
           em.persist(u);
           System.out.println("inserted successfuly");
       }catch(Exception eq)
       {
           System.out.println("Failed insertion");
       }    
   }
   
   @Override
   public void deleteUser(int userId)
   {
       try{
           User u=em.find(User.class, userId);
           if(u!=null)
           {
               em.remove(u);
                System.out.println("deletion successfuly");
           }else
           {    
                System.out.println("in not found");
           }
       }catch(Exception eq)
       {
           System.out.println("Failed deletion");
       }    
   }
   
   @Override
   public void updateUser(int userId,int roleId,int subscriptionId,String email,String firstName,String lastName,String password,BigInteger phoneNo,Date dateOfBirth,String gender,String address,BigInteger emergencyNo,String profile,int pincode,String state,String city,String specialization,String medicalLicense,String yearExperience,String degree,String certificate,String affiliateHospital,String currentPosition,String workSchedule,Date registrationDate,String bio,String hospitalName,String website,Date expiarydate,String macAddress,String status)
   {
        try{
            Role role = em.find(Role.class, roleId);
            if (role == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + role);
            }
             Subscription subscription = em.find(Subscription.class, subscriptionId);
            if (subscription == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + subscription);
            }
           User u=em.find(User.class, userId);
           u.setRoleId(role);
           u.setSubscriptionId(subscription);
           u.setEmail(email);
           u.setFirstName(firstName);
           u.setLastName(lastName);
           u.setPassword(password);
           u.setPhoneNo(phoneNo);
           u.setDateOfBirth(dateOfBirth);
           u.setGender(gender);
           u.setAddress(address);
           u.setEmergencyNo(emergencyNo);
           u.setProfile(profile);
           u.setPincode(pincode);
           u.setState(state);
           u.setCity(city);
           u.setSpecialization(specialization);
           u.setMedicalLicense(medicalLicense);
           u.setYearOfExpirence(yearExperience);
           u.setDegree(degree);
           u.setCertification(certificate);
           u.setAffiliateHospital(affiliateHospital);
           u.setCurrentPosition(currentPosition);
           u.setWorkSchedule(workSchedule);
           u.setRegistrationDate(registrationDate);
           u.setBio(bio);
           u.setHospitalName(hospitalName);
           u.setWebsite(website);
           u.setExpiaryDate(expiarydate);
           u.setMacAddress(macAddress);
           u.setStatus(status);
           u.setUpdatedAt(new Date());
           em.merge(u);
           System.out.println("updated successfuly");
       }catch(Exception eq)
       {
           System.out.println("Failed updated");
       }    
   }  

}
