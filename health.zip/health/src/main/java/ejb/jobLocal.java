/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import entity.Job;
import jakarta.ejb.Local;
import java.math.BigInteger;
import java.util.List;
/**
 *
 * @author palad
 */
@Local
public interface jobLocal {
       void addJob(int userId,int careerId,String name,String email,BigInteger phoneNo,String resume,String status);
    void deleteJob(int jobId);
    void updateJob(int jobId,int userId,int careerId,String name,String email,BigInteger phoneNo,String resume,String status);
   List<Job> getAllJobs();
}
