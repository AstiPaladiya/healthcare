/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.Product;
import entity.Category;
import entity.User;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Stateless
public class product implements productLocal {

   @PersistenceContext(unitName="health")
   EntityManager em;
   
    @Override
    public List<Product> getAllProducts()
    {
                return em.createNamedQuery("Product.findAll", Product.class).getResultList();

    }
   @Override
   public void addProduct(int categoryId,int userId,String companyName,String prescription,String medicineName,String description,float price,String img1,String img2,String img3,String img4,int quantity,int availableQuantity,float offer,String productStatus,int blockedBy)   {
       try{
            Category c = em.find(Category.class, categoryId);
            if (c == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + c);
            }
             User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
           Product p=new Product();
           p.setCategoryId(c);
           p.setUserId(u);
           p.setCompanyName(companyName);
           p.setPrescription(prescription);
           p.setMedicineName(medicineName);
           p.setDescription(description);
           p.setPrice(price);
           p.setImg1(img1);
           p.setImg2(img2);
           p.setImg3(img3);
           p.setImg4(img4);
           p.setQuantity(quantity);
           p.setAvailableQuantity(availableQuantity);
           p.setOffer(offer);
           p.setProductStatus(productStatus);
           p.setBlockedBy(blockedBy);
          
           Date d=new Date();
           p.setCreatedAt(d);
           p.setUpdatedAt(d);
           em.persist(p);
           System.out.println("inserted successfuly");
       }catch(Exception eq)
       {
           System.out.println("Failed insertion");
       }    
   }
   
   @Override
   public void deleteProduct(int productId)
   {
       try{
           Product p=em.find(Product.class, productId);
           if(p!=null)
           {
               em.remove(p);
                System.out.println("deletion successfuly");
           }else
           {    
                System.out.println("in not found");
           }
       }catch(Exception eq)
       {
           System.out.println("Failed deletion");
       }    
   }
   
   @Override
   public void updateProduct(int productId,int categoryId,int userId,String companyName,String prescription,String medicineName,String description,float price,String img1,String img2,String img3,String img4,int quantity,int availableQuantity,float offer,String productStatus,int blockedBy)
   {
        try{
            Category c = em.find(Category.class, categoryId);
            if (c == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + c);
            }
             User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
           Product p=em.find(Product.class, productId);
            p.setCategoryId(c);
           p.setUserId(u);
           p.setCompanyName(companyName);
           p.setPrescription(prescription);
           p.setMedicineName(medicineName);
           p.setDescription(description);
           p.setPrice(price);
           p.setImg1(img1);
           p.setImg2(img2);
           p.setImg3(img3);
           p.setImg4(img4);
           p.setQuantity(quantity);
           p.setAvailableQuantity(availableQuantity);
           p.setOffer(offer);
           p.setProductStatus(productStatus);
           p.setBlockedBy(blockedBy);
           p.setUpdatedAt(new Date());
           em.merge(p);
           System.out.println("updated successfuly");
       }catch(Exception eq)
       {
           System.out.println("Failed updated");
       }    
   }  

}

