/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import entity.Career;
import jakarta.ejb.Local;
import java.util.List;
/**
 *
 * @author palad
 */
@Local
public interface careerLocal {
    void addCareer(int userId,String careername,String time,String description,String experience,String degree,String status);
    void deleteCareer(int careerId);
    void updateCareer(int blogId,int userId,String careername,String time,String description,String experience,String degree,String status);
   List<Career> getAllCareers();
}
