/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.User;
import entity.CheckupBooking;
import jakarta.ejb.Stateless;
import java.util.Date;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Set;
/**
 *
 * @author palad
 */
@Stateless
public class checkupbooking implements checkupbookingLocal {

    @PersistenceContext(unitName="health")
    EntityManager em;
    
     @Override
     public List<CheckupBooking> getAllCheckupBookings()
     {
          return em.createNamedQuery("CheckupBooking.findAll",CheckupBooking.class).getResultList();
//         return em.createQuery("SELECT new yourpackage.CategoryWithRoleNameDTO(c.name, c.description, c.image, c.status, r.name) " +
//                          "FROM Category c JOIN c.role r", CategoryWithRoleNameDTO.class)
//             .getResultList();
     }
     @Override
    public void addCheckupBooking(int userId,int bussinessId,String schedule,float price,String status)
    {
        try{
            User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
            User b = em.find(User.class, bussinessId);
            if (b== null) {
                throw new IllegalArgumentException("Role ID does not exist: " + b);
            }

            CheckupBooking c=new CheckupBooking();
            c.setUserId(u);
            c.setBussinessId(b);
            c.setSchedule(schedule);
            c.setPrice(price);
            c.setStatus(status);
            Date currentDate=new Date();
            c.setCreatedAt(currentDate);
            c.setUpdatedAt(currentDate);
            em.persist(c);
            System.out.println("Added successfuly");
        }catch(Exception eq)
        {
            eq.printStackTrace();
            System.out.println("Failrd insertion");
        }
    }
    @Override
    public void deleteCheckupBooking(int checkupId)
    {
        try{
            CheckupBooking c=em.find(CheckupBooking.class, checkupId);
            if(c!=null)
            {
                em.remove(c);
                System.out.println("Deleted successfully");
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed Deletion");
        }
    }
      @Override
    public void updateCheckupBooking(int checkupId,int userId,int bussinessId,String schedule,float price,String status)
    {
        try{
              User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
            User b = em.find(User.class, bussinessId);
            if (b== null) {
                throw new IllegalArgumentException("Role ID does not exist: " + b);
            }
            CheckupBooking c=em.find(CheckupBooking.class, checkupId);
            if(c!=null)
            {
               c.setUserId(u);
                c.setBussinessId(b);
                c.setSchedule(schedule);
                c.setPrice(price);
                c.setStatus(status);

            c.setUpdatedAt(new Date());
                em.merge(c);
                System.out.println("updated successfuly");
                
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
        
    }
}

