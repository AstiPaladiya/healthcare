/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import jakarta.ejb.Local;
import entity.PrivacyPolicy;
import java.util.List;
/**
 *
 * @author palad
 */
@Local
public interface privacypolicyLocal {
    void addPrivacyPolicy(String name,String description,String status);
    void deletePrivacyPolicy(int privacyId);
    void updatePrivacyPolicy(int privacyId,String name,String desctription,String status);
    List<PrivacyPolicy> getAllPrivacyPolicys();
}
