/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.User;
import entity.HealthWellness;
import jakarta.ejb.Stateless;
import java.util.Date;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.math.BigInteger;
import java.util.Set;
/**
 *
 * @author palad
 */
@Stateless
public class healthwellness implements healthwellnessLocal {

  @PersistenceContext(unitName="health")
    EntityManager em;
    
     @Override
     public List<HealthWellness> getAllHealthWellnesss()
     {
          return em.createNamedQuery("HealthWellness.findAll",HealthWellness.class).getResultList();
//         return em.createQuery("SELECT new yourpackage.CategoryWithRoleNameDTO(c.name, c.description, c.image, c.status, r.name) " +
//                          "FROM Category c JOIN c.role r", CategoryWithRoleNameDTO.class)
//             .getResultList();
     }
     @Override
    public void addHealthWellness(int userId,String address,String schedule,String description,BigInteger phoneNo,String status)
    {
        try{
            User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
          
            HealthWellness h=new HealthWellness();
            h.setUserId(u);
            h.setAddress(address);
            h.setSchedule(schedule);
            h.setDescription(description);
            h.setPhoneNo(phoneNo);
            h.setStatus(status);
            Date currentDate=new Date();
            h.setCreatedAt(currentDate);
            h.setUpdatedAt(currentDate);
            em.persist(h);
            System.out.println("Added successfuly");
        }catch(Exception eq)
        {
            eq.printStackTrace();
            System.out.println("Failrd insertion");
        }
    }
    @Override
    public void deleteHealthWellness(int healthId)
    {
        try{
            HealthWellness h=em.find(HealthWellness.class, healthId);
            if(h!=null)
            {
                em.remove(h);
                System.out.println("Deleted successfully");
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed Deletion");
        }
    }
    @Override
    public void updateHealthWellness(int healthId,int userId,String address,String schedule,String description,BigInteger phoneNo,String status)
    {
        try{
             User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + userId);
            }
           
            HealthWellness h=em.find(HealthWellness.class, healthId);
            if(h!=null)
            {
                h.setUserId(u);
                h.setAddress(address);
                h.setSchedule(schedule);
                h.setDescription(description);
                h.setPhoneNo(phoneNo);
                h.setStatus(status);
                h.setUpdatedAt(new Date());
                em.merge(h);
                System.out.println("updated successfuly");
                
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
        }
}
