/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.Category;
import entity.Role;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Set;
/**
 *
 * @author palad
 */
@Stateless
public class category implements categoryLocal {

    @PersistenceContext(unitName="health")
    EntityManager em;
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
     @Override
     public List<Category> getAllCategoryes()
     {
          return em.createNamedQuery("Category.findAll",Category.class).getResultList();
//         return em.createQuery("SELECT new yourpackage.CategoryWithRoleNameDTO(c.name, c.description, c.image, c.status, r.name) " +
//                          "FROM Category c JOIN c.role r", CategoryWithRoleNameDTO.class)
//             .getResultList();
     }
    @Override
    public void addCategory(int roleId,String name,String description,String image,String status)
    {
        try{
            Role role = em.find(Role.class, roleId);
            if (role == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + roleId);
            }
            Category c=new Category();
            c.setRoleId(role);
            c.setName(name);
            c.setDescription(description);
            c.setImage(image);
            c.setStatus(status);
            Date currentDate=new Date();
            c.setCreatedAt(currentDate);
            c.setUpdatedAt(currentDate);
            em.persist(c);
            System.out.println("Added successfuly");
        }catch(Exception eq)
        {
            eq.printStackTrace();
            System.out.println("Failrd insertion");
        }
    }
    
    @Override
    public void deleteCategory(int categoryId)
    {
        try{
            Category c=em.find(Category.class, categoryId);
            if(c!=null)
            {
                em.remove(c);
                System.out.println("Deleted successfully");
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed Deletion");
        }
    }
      @Override
    public void updateCategory(int categoryId,int roleId,String name,String description,String image,String status)
    {
        try{
             Role role = em.find(Role.class, roleId);
            if (role == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + roleId);
            }
            Category c=em.find(Category.class, categoryId);
            if(c!=null)
            {
                c.setRoleId(role);
                c.setName(name);
                c.setDescription(description);
                c.setImage(image);
                c.setStatus(status);
                c.setUpdatedAt(new Date());
                em.merge(c);
                System.out.println("updated successfuly");
                
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
        
    }
    
    
}
