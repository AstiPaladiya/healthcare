/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.Subscription;
import entity.User;
import entity.SubscriptionUser;

import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Stateless
public class subscriptionuser implements subscriptionuserLocal {

     @PersistenceContext(unitName="health")
    EntityManager em;
      @Override
    public List<SubscriptionUser> getAllSubscriptionUsers() {
         // Use the named query with Role.class to return a list of Role entities
        return em.createNamedQuery("SubscriptionUser.findAll", SubscriptionUser.class).getResultList();
    }
    @Override
    public void addSubscriptionUser(int subscriptionId,int userId,Date expiaryDate,String paymentMode,String status)
    {
        try{
             User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
             Subscription subscription = em.find(Subscription.class, subscriptionId);
            if (subscription == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + subscription);
            }
            SubscriptionUser s=new SubscriptionUser();
            s.setSubscriptionId(subscription);
            s.setUserId(u);
            s.setPaymentMode(paymentMode);
            s.setExpiaryDate(expiaryDate);
            Date d=new Date();
            s.setCreatedAt(d);
            s.setUpdatedAt(d);
            s.setStatus(status);
            em.persist(s);
             System.out.println("Insertin Succsesfuly");
        }catch(Exception eq)
        {
            System.out.println("Insertin failed");
        }
    }
    @Override
    public void deleteSubscriptionUser(int subscriptionuserId)
    {
        try{
            SubscriptionUser s=em.find(SubscriptionUser.class, subscriptionuserId);
            if(s!=null)
            {
                em.remove(s);
                System.out.println("Deletion failed");
            }else{
                System.out.println("Id not found ");

            }
        }catch(Exception eq)
        {
            System.out.println("deletion failed");
        }  
    }
   @Override
    public void updateSubscriptionUser(int subscriptionuserId,int subscriptionId,int userId,Date expiaryDate,String paymentMode,String status)
    {
        try{
            User u = em.find(User.class, userId);
            if (u == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + u);
            }
             Subscription subscription = em.find(Subscription.class, subscriptionId);
            if (subscription == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + subscription);
            }
             SubscriptionUser s=em.find(SubscriptionUser.class, subscriptionuserId);
            if(s!=null)
            {
                s.setSubscriptionId(subscription);
                s.setUserId(u);
                s.setPaymentMode(paymentMode);
                s.setExpiaryDate(expiaryDate);
                s.setUpdatedAt(new Date());
                s.setStatus(status);
                em.merge(s);
             System.out.println("Updation Succsesfuly");
            }else{
                System.out.println("Id not found ");

            }
        }catch(Exception eq)
        {
            System.out.println("updation failed");
        }  
    
    }
}
