/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import entity.Blog;
import jakarta.ejb.Local;
import java.util.List;

/**
 *
 * @author palad
 */
@Local
public interface blogLocal {
     void addBlog(int userId,String name,String description,String status);
    void deleteBlog(int blogId);
    void updateBlog(int blogId,int userId,String name,String description,String status);
   List<Blog> getAllBlogs();
}
