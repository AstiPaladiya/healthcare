/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.HealthRecord;
import entity.MedicalReport;
import jakarta.ejb.Stateless;
import java.util.Date;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.math.BigInteger;
import java.util.Set;
/**
 *
 * @author palad
 */
@Stateless
public class medicalreport implements medicalreportLocal {
  @PersistenceContext(unitName="health")
    EntityManager em;
    
     @Override
     public List<MedicalReport> getAllMedicalReports()
     {
          return em.createNamedQuery("MedicalReport.findAll",MedicalReport.class).getResultList();
//         return em.createQuery("SELECT new yourpackage.CategoryWithRoleNameDTO(c.name, c.description, c.image, c.status, r.name) " +
//                          "FROM Category c JOIN c.role r", CategoryWithRoleNameDTO.class)
//             .getResultList();
     }
     @Override
    public void addMedicalReport(int healthId,String reportName,String reportType,Date reportDate,String reportStatus,String summery,String status)
    {
        try{
            HealthRecord h = em.find(HealthRecord.class, healthId);
            if (h == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + h);
            }
            
            MedicalReport m=new MedicalReport();
            m.setHealthRecordId(h);
            m.setReportName(reportName);
            m.setReportType(reportType);
            m.setReportDate(reportDate);
            m.setReportStatus(reportStatus);
            m.setSummery(summery);
            m.setStatus(status);
            Date currentDate=new Date();
            m.setCreatedAt(currentDate);
            m.setUpdatedAt(currentDate);
            em.persist(m);
            System.out.println("Added successfuly");
        }catch(Exception eq)
        {
            eq.printStackTrace();
            System.out.println("Failrd insertion");
        }
    }
    @Override
    public void deleteMedicalReport(int medicalId)
    {
        try{
            MedicalReport m=em.find(MedicalReport.class, medicalId);
            if(m!=null)
            {
                em.remove(m);
                System.out.println("Deleted successfully");
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed Deletion");
        }
    }
    @Override
    public void updateMedicalReport(int medicalId,int healthId,String reportName,String reportType,Date reportDate,String reportStatus,String summery,String status)
    {
        try{
              HealthRecord h = em.find(HealthRecord.class, healthId);
            if (h == null) {
                throw new IllegalArgumentException("Role ID does not exist: " + h);
            }
            MedicalReport m=em.find(MedicalReport.class, medicalId);
            if(m!=null)
            {
                m.setHealthRecordId(h);
                m.setReportName(reportName);
                m.setReportType(reportType);
                m.setReportDate(reportDate);
                m.setReportStatus(reportStatus);
                m.setSummery(summery);
                m.setStatus(status);
                m.setUpdatedAt(new Date());
                em.merge(m);
                System.out.println("updated successfuly");
                
            }else{
                System.out.println("Id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
        
    }
}
