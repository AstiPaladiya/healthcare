/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package ejb;

import jakarta.ejb.Stateless;
import entity.TermsCondition;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
/**
 *
 * @author palad
 */
@Stateless
public class termscondition implements termsconditionLocal {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @PersistenceContext(unitName="health")
    EntityManager em;
    
    @Override
    public List<TermsCondition> getAllTermsConditions()
    {
                return em.createNamedQuery("TermsCondition.findAll", TermsCondition.class).getResultList();

    }
    
    @Override
    public void addTermsCondition(String name,String description,String status)
    {
        try{
            TermsCondition t=new TermsCondition();
            t.setName(name);
            t.setDescription(description);
            t.setStatus(status);
            Date d=new Date();
            t.setCreatedAt(d);
            t.setUpdatedAt(d);
            em.persist(t);
            System.out.println("insertion successfully");
        }catch(Exception eq)
        {
            System.out.println("Failed insertion");
        }
    }
    
    @Override
    public void deleteTermsCondition(int termsId)
    {
        try{
            TermsCondition t=em.find(TermsCondition.class,termsId);
            if(t!=null)
            {
                em.remove(t);
                 System.out.println("deletion successfully");
            }else
            {
                System.out.println("id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed deeletion");
        }
    }
    
    @Override
    public void updateTermsCondition(int termsId,String name,String description,String status)
    {
        try{
            TermsCondition t=em.find(TermsCondition.class, termsId);
            if(t!=null)
            {
                t.setName(name);
                t.setDescription(description);
                t.setStatus(status);
                t.setUpdatedAt(new Date());
                em.merge(t);
                System.out.println("updation successfully");
            }else
            {
                System.out.println("id not found");
            }
        }catch(Exception eq)
        {
            System.out.println("Failed updation");
        }
    }
}   
