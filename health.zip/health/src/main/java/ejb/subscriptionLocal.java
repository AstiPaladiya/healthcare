/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import jakarta.ejb.Local;
import entity.Subscription;
import java.util.List;
/**
 *
 * @author palad
 */
@Local
public interface subscriptionLocal {
    void addSubscription(String plan_name,String plan_detail,float price,int time_period,String status);
    void deleteSubscription(int subscriptionId);
    void updateSubscription(int subscriptionId,String plan_name,String plan_detail,float price,int time_period,String status);
      List<Subscription> getAllSubscriptions();
}
