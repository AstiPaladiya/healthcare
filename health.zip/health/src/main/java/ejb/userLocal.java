/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package ejb;

import jakarta.ejb.Local;
import entity.Role;
import entity.Subscription;
import entity.User;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 *
 * @author palad
 */
@Local
public interface userLocal {
   void addUser(int roleId,int subscriptionId,String email,String firstName,String lastName,String password,BigInteger phoneNo,Date dateOfBirth,String gender,String address,BigInteger emergencyNo,String profile,int pincode,String state,String city,String specialization,String medicalLicense,String yearExperience,String degree,String certificate,String affiliateHospital,String currentPosition,String workSchedule,Date registrationDate,String bio,String hospitalName,String website,Date expiarydate,String macAddress,String status); 
   void deleteUser(int userId);
   void updateUser(int userId,int roleId,int subscriptionId,String email,String firstName,String lastName,String password,BigInteger phoneNo,Date dateOfBirth,String gender,String address,BigInteger emergencyNo,String profile,int pincode,String state,String city,String specialization,String medicalLicense,String yearExperience,String degree,String certificate,String affiliateHospital,String currentPosition,String workSchedule,Date registrationDate,String bio,String hospitalName,String website,Date expiarydate,String macAddress,String status); 
List<User> getAllUsers();
}
