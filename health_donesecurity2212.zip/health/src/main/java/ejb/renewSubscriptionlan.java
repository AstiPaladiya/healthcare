/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package ejb;

import javax.ejb.Stateless;
import  entity.User;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
/**
 *
 * @author palad
 */
@Stateless
public class renewSubscriptionlan implements renewSubscriptionlanLocal {

     @PersistenceContext(unitName = "health")
    EntityManager em;
     
     @Override
     public Date getUserExpirationDate(String username) {
        try {
            TypedQuery<Date> query = em.createQuery(
                "SELECT u.expiaryDate FROM User u WHERE u.email = :username", Date.class);
            query.setParameter("username", username);
            return query.getSingleResult();
        } catch (Exception e) {
            // Handle exception (e.g., NoResultException if the user is not found)
            e.printStackTrace();
            return null;
        }
    }
}
