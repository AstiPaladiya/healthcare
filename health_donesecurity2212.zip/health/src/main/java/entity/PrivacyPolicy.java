/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 *
 * @author palad
 */
@Entity
@Table(name = "privacy_policy")
@NamedQueries({
    @NamedQuery(name = "PrivacyPolicy.findAll", query = "SELECT p FROM PrivacyPolicy p"),
    @NamedQuery(name = "PrivacyPolicy.findById", query = "SELECT p FROM PrivacyPolicy p WHERE p.id = :id"),
    @NamedQuery(name = "PrivacyPolicy.findByName", query = "SELECT p FROM PrivacyPolicy p WHERE p.name = :name"),
    @NamedQuery(name = "PrivacyPolicy.findByStatus", query = "SELECT p FROM PrivacyPolicy p WHERE p.status = :status"),
    @NamedQuery(name = "PrivacyPolicy.findByCreatedAt", query = "SELECT p FROM PrivacyPolicy p WHERE p.createdAt = :createdAt"),
    @NamedQuery(name = "PrivacyPolicy.findByUpdatedAt", query = "SELECT p FROM PrivacyPolicy p WHERE p.updatedAt = :updatedAt")})
public class PrivacyPolicy implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 400)
    @Column(name = "name")
    private String name;
    @Lob
    @Size(max = 65535)
    @Column(name = "description")
    private String description;
    @Size(max = 200)
    @Column(name = "status")
    private String status;
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Column(name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    public PrivacyPolicy() {
    }

    public PrivacyPolicy(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrivacyPolicy)) {
            return false;
        }
        PrivacyPolicy other = (PrivacyPolicy) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.PrivacyPolicy[ id=" + id + " ]";
    }
    
}
