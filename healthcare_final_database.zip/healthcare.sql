-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2024 at 09:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(500) DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `user_id`, `name`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(12, 62, 'body changes ', 'IMG_1735116176403slider-bg-1.jpg', 'this is body type.. very helpfull for any bactreia protection\r\nthis is helath care about body', 'Active', '2024-12-25 08:27:03', '2024-12-26 04:52:40'),
(13, 62, 'organs michenishm', 'IMG_1735116203124bg-4.jpg', 'this is body type.  michenichal.\r\nthis is helath care about body organs', 'Active', '2024-12-25 08:28:19', '2024-12-25 08:43:31'),
(14, 62, 'mouth desceses', 'IMG_1735116244277banner.jpg', 'many desceses occures in mouth.....', 'Active', '2024-12-25 08:44:04', '2024-12-26 04:54:27');

-- --------------------------------------------------------

--
-- Table structure for table `career`
--

CREATE TABLE `career` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `carrer_name` varchar(400) DEFAULT NULL,
  `time` varchar(400) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `experience` varchar(300) DEFAULT NULL,
  `degree` varchar(500) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `role_id`, `name`, `description`, `image`, `status`, `created_at`, `updated_at`) VALUES
(21, 12, 'Ophthalmology', 'Expert eye care for vision correction, cataract treatments, and more.', 'IMG_1734970978503service-1.jpg', 'Active', '2024-12-23 16:22:58', '2024-12-23 16:22:58'),
(22, 12, 'Cardiology', 'Heart health services including consultations, ECG, and treatment for cardiovascular conditions.', 'IMG_1734971059694service-2.jpg', 'Active', '2024-12-23 16:24:19', '2024-12-23 16:24:19'),
(23, 12, 'Dental Care', 'Comprehensive dental services ranging from routine check-ups to specialized procedures.', 'IMG_1734971243291service-3.jpg', 'Active', '2024-12-23 16:27:23', '2024-12-23 16:27:23'),
(24, 12, 'Gynecology', 'Women’s health services including routine exams, prenatal care, and reproductive health.', 'IMG_1734971299387service-4.jpg', 'Active', '2024-12-23 16:28:19', '2024-12-23 16:28:19'),
(25, 12, 'Pulmonology', 'Specialized care for lung diseases, respiratory issues, and asthma management.', 'IMG_1734971632411service-6.jpg', 'Active', '2024-12-23 16:33:52', '2024-12-23 16:33:52'),
(26, 10, 'Homiyopathic', 'this is homyopathic medicine very helpfull for health.', 'IMG_1735045716210about-1.jpg', 'Active', '2024-12-24 13:08:36', '2024-12-24 13:12:46'),
(27, 10, 'Childmedicine', 'This medicine is for chiled', 'IMG_1735045944424img-3.jpg', 'Active', '2024-12-24 13:12:24', '2024-12-24 13:12:24'),
(28, 12, 'xyz', 'dfsd', 'IMG_1735051347053img-2.jpg', 'Active', '2024-12-24 14:42:27', '2024-12-24 14:42:27');

-- --------------------------------------------------------

--
-- Table structure for table `chat_master`
--

CREATE TABLE `chat_master` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `reciever_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `reciever_by_reciever` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `checkup_booking`
--

CREATE TABLE `checkup_booking` (
  `id` int(11) NOT NULL,
  `bussiness_id` int(11) DEFAULT NULL,
  `schedule` varchar(500) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkup_booking`
--

INSERT INTO `checkup_booking` (`id`, `bussiness_id`, `schedule`, `price`, `status`, `created_at`, `updated_at`) VALUES
(14, 62, 'this is for monday to saturday available till 10 to 20 april only 2 days', 30, 'Block', '2024-12-25 07:13:25', '2024-12-26 05:16:20'),
(15, 62, 'this is for monday to saturday available till 10 to 20 april', 240, 'Active', '2024-12-25 07:14:00', '2024-12-25 07:53:00'),
(16, 63, 'hello this is schedule', 120, 'Active', '2024-12-25 07:25:53', NULL),
(17, 62, 'this is for monday to saturday available till 10 to 20 april only 2 days', 30, 'Active', '2024-12-25 07:56:00', '2024-12-25 07:56:00');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `complain` text DEFAULT NULL,
  `against_complain_id` int(11) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(300) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `feedback`, `created_at`, `updated_at`) VALUES
(1, 'dinesh', 'dinesh@gmail.com', 'this website is good.', '2024-12-21 03:16:41', NULL),
(2, 'vimala', 'vimala@gmail.com', 'sds dfsd', '2024-12-21 03:17:29', NULL),
(3, 'hello', 'tIn this website have a problem', NULL, '2024-12-25 13:25:02', '2024-12-25 13:25:02'),
(4, 'hello', 'tIn this website have a problem', 'hello This website have some problem related appoinment', '2024-12-25 13:25:52', '2024-12-25 13:25:52'),
(5, 'fgfd', 'dsfs', 'asd', '2024-12-25 13:28:04', '2024-12-25 13:28:04');

-- --------------------------------------------------------

--
-- Table structure for table `health_record`
--

CREATE TABLE `health_record` (
  `id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `appointment_time` time DEFAULT NULL,
  `paitent_name` varchar(300) DEFAULT NULL,
  `paitent_phoneno` bigint(20) DEFAULT NULL,
  `paitent_email` varchar(400) DEFAULT NULL,
  `information` text DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `health_record`
--

INSERT INTO `health_record` (`id`, `book_id`, `patient_id`, `appointment_date`, `appointment_time`, `paitent_name`, `paitent_phoneno`, `paitent_email`, `information`, `status`, `created_at`, `updated_at`) VALUES
(8, 14, 64, '2024-09-23', NULL, NULL, 34543544, 'sds@gmail.com', 'DFDS', 'Pending', '2024-12-25 16:14:07', '2024-12-25 16:14:07'),
(9, 16, 64, '2023-05-20', NULL, 'hari panchal', 3534543544, 'panchal@gmail.com', 'tIn this website have a problem', 'Pending', '2024-12-25 16:17:57', '2024-12-25 16:17:57'),
(10, 15, 64, '2025-09-21', NULL, 'dixa', 956004545, 'dixa@gmail.com', 'tIn this website have a problem', 'Pending', '2024-12-25 16:26:29', '2024-12-25 16:26:29'),
(11, 16, 64, '2025-01-24', NULL, 'krupali', 536627291, 'xyz@gmail.com', 'i want book appountment for health checkup', 'Pending', '2024-12-26 04:56:55', '2024-12-26 04:56:55'),
(12, 15, 64, '2025-01-10', NULL, 'ABc ', 728900912, 'abc@gmail.com', 'Iwant visit for consulltation', 'Pending', '2024-12-26 05:20:41', '2024-12-26 05:20:41');

-- --------------------------------------------------------

--
-- Table structure for table `health_wellness`
--

CREATE TABLE `health_wellness` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `schedule` varchar(400) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `phone_no` bigint(20) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `career_id` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone_no` bigint(20) DEFAULT NULL,
  `resume` varchar(300) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medical_report`
--

CREATE TABLE `medical_report` (
  `id` int(11) NOT NULL,
  `health_record_id` int(11) DEFAULT NULL,
  `report_name` varchar(400) DEFAULT NULL,
  `report_type` varchar(300) DEFAULT NULL,
  `report_date` date DEFAULT NULL,
  `report_status` varchar(200) DEFAULT NULL,
  `summery` text DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `order_master_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_master`
--

CREATE TABLE `order_master` (
  `id` int(11) NOT NULL,
  `bill_no` int(11) DEFAULT NULL,
  `buyer_user_id` int(11) DEFAULT NULL,
  `reciever_name` varchar(300) DEFAULT NULL,
  `phone_no` bigint(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `total_amount` float DEFAULT NULL,
  `selling_date` date DEFAULT NULL,
  `payment_mode` varchar(300) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `privacy_policy`
--

CREATE TABLE `privacy_policy` (
  `id` int(11) NOT NULL,
  `name` varchar(400) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `privacy_policy`
--

INSERT INTO `privacy_policy` (`id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'privacy', 'This is privacy', 'Active', '2024-11-09 20:15:11', '2024-11-09 20:15:11'),
(2, 'privacy', 'This is privacy', 'Active', '2024-11-09 20:15:22', '2024-11-09 20:15:22'),
(3, 'policy', 'This is policy', 'Block', '2024-11-09 20:15:24', '2024-11-09 20:22:12'),
(6, 'privacy', 'This is privacy', 'Active', '2024-11-09 20:22:23', '2024-11-09 20:22:23'),
(7, 'privacy', 'This is privacy', 'Active', '2024-11-09 20:27:10', '2024-11-09 20:27:10');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `prescription` text DEFAULT NULL,
  `medicine_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` float DEFAULT NULL,
  `img1` varchar(400) DEFAULT NULL,
  `img2` varchar(400) DEFAULT NULL,
  `img3` varchar(400) DEFAULT NULL,
  `img4` varchar(400) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `available_quantity` int(11) DEFAULT NULL,
  `offer` float DEFAULT NULL,
  `product_status` varchar(200) DEFAULT NULL,
  `blocked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `return_order`
--

CREATE TABLE `return_order` (
  `id` int(11) NOT NULL,
  `order_detail_id` int(11) DEFAULT NULL,
  `order_problem` text DEFAULT NULL,
  `img` varchar(400) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(300) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(7, 'Admin', 'Active', '2024-11-07 08:11:07', '2024-12-25 11:24:26'),
(10, 'Pharmacist', 'Active', '2024-11-08 12:19:41', '2024-12-24 12:51:23'),
(12, 'Doctor', 'Active', '2024-11-09 04:22:50', '2024-12-22 13:13:24'),
(13, 'User', 'Active', '2024-11-09 04:22:57', '2024-12-22 13:40:25'),
(77, 'Nurse1', 'null', '2024-12-24 12:55:19', '2024-12-24 12:59:35'),
(78, 'Nurse', 'Block', '2024-12-24 12:55:29', '2024-12-24 12:59:24'),
(79, 'COmponder', 'Active', '2024-12-24 12:59:06', '2024-12-24 12:59:27'),
(80, 'Nurs', 'null', '2024-12-24 13:05:52', '2024-12-24 13:05:52');

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `id` int(11) NOT NULL,
  `plan_name` varchar(300) DEFAULT NULL,
  `plan_detail` text DEFAULT NULL,
  `price` float DEFAULT NULL,
  `time_period` int(11) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscription`
--

INSERT INTO `subscription` (`id`, `plan_name`, `plan_detail`, `price`, `time_period`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Golden Plan', 'This is Golden plan', 100.9, 199, 'Active', '2024-11-09 12:12:45', '2024-12-26 04:51:12'),
(3, 'Silver Plan', 'This is silver plan', 200.9, 299, 'Active', '2024-11-09 12:13:14', '2024-11-09 12:13:14'),
(7, 'golden jubliee Plan', 'This is golden plan', 123, 200, 'Active', '2024-12-15 08:13:07', '2024-12-26 04:51:07');

-- --------------------------------------------------------

--
-- Table structure for table `subscription_user`
--

CREATE TABLE `subscription_user` (
  `id` int(11) NOT NULL,
  `subscription_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expiary_date` date DEFAULT NULL,
  `payment_mode` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscription_user`
--

INSERT INTO `subscription_user` (`id`, `subscription_id`, `user_id`, `expiary_date`, `payment_mode`, `status`, `created_at`, `updated_at`) VALUES
(6, 2, 63, '2025-07-09', 'Online', NULL, '2024-12-22 10:26:09', '2024-12-22 10:26:09'),
(7, 7, 64, '2025-07-10', 'Online', NULL, '2024-12-22 10:27:44', '2024-12-22 10:27:44'),
(8, 7, 65, '2025-07-10', 'Online', NULL, '2024-12-22 10:28:36', '2024-12-22 10:28:36'),
(9, 3, 66, '2025-10-17', 'Online', NULL, '2024-12-22 10:30:52', '2024-12-22 10:30:52'),
(10, 7, 67, '2025-07-10', 'Online', NULL, '2024-12-22 11:00:51', '2024-12-22 11:00:51'),
(11, 7, 35, '2025-07-11', 'Online', NULL, '2024-12-23 13:10:02', '2024-12-23 13:10:02'),
(12, 7, 64, '2025-07-13', 'Online', NULL, '2024-12-25 10:24:37', '2024-12-25 10:24:37'),
(13, 7, 64, '2025-07-13', 'Online', NULL, '2024-12-25 16:04:47', '2024-12-25 16:04:47'),
(14, 2, 68, '2025-07-13', 'Online', NULL, '2024-12-25 22:17:50', '2024-12-25 22:17:50'),
(15, 3, 69, '2025-10-21', 'Online', NULL, '2024-12-26 02:59:55', '2024-12-26 02:59:55'),
(16, 2, 68, '2025-07-13', 'Online', NULL, '2024-12-26 04:54:56', '2024-12-26 04:54:56'),
(17, 2, 70, '2025-07-13', 'Online', NULL, '2024-12-26 05:14:44', '2024-12-26 05:14:44');

-- --------------------------------------------------------

--
-- Table structure for table `terms_condition`
--

CREATE TABLE `terms_condition` (
  `id` int(11) NOT NULL,
  `name` varchar(400) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `terms_condition`
--

INSERT INTO `terms_condition` (`id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'terms', 'This is terms', 'Active', '2024-11-09 19:36:13', '2024-11-09 19:36:13'),
(2, 'condition', 'This is description', 'Block', '2024-11-09 19:36:23', '2024-11-09 20:00:42');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `subscription_id` int(11) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `first_name` text DEFAULT NULL,
  `last_name` text DEFAULT NULL,
  `password` text DEFAULT NULL,
  `phone_no` bigint(20) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(300) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `emergency_no` bigint(20) DEFAULT NULL,
  `profile` text DEFAULT NULL,
  `pincode` int(11) DEFAULT NULL,
  `state` varchar(400) DEFAULT NULL,
  `city` varchar(400) DEFAULT NULL,
  `specialization` text DEFAULT NULL,
  `medical_license` varchar(400) DEFAULT NULL,
  `year_of_expirence` varchar(300) DEFAULT NULL,
  `degree` varchar(250) DEFAULT NULL,
  `certification` text DEFAULT NULL,
  `affiliate_hospital` text DEFAULT NULL,
  `current_position` varchar(400) DEFAULT NULL,
  `work_schedule` varchar(500) DEFAULT NULL,
  `registration_date` date DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `hospital_name` text DEFAULT NULL,
  `website` varchar(400) DEFAULT NULL,
  `expiary_date` date DEFAULT NULL,
  `mac_address` varchar(400) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `role_id`, `subscription_id`, `email`, `first_name`, `last_name`, `password`, `phone_no`, `date_of_birth`, `gender`, `address`, `emergency_no`, `profile`, `pincode`, `state`, `city`, `specialization`, `medical_license`, `year_of_expirence`, `degree`, `certification`, `affiliate_hospital`, `current_position`, `work_schedule`, `registration_date`, `bio`, `hospital_name`, `website`, `expiary_date`, `mac_address`, `status`, `created_at`, `updated_at`) VALUES
(35, 10, 7, 'paladiyaasti@gmail.com', 'Paladiya', 'asti', 'PBKDF2WithHmacSHA256:2048:29RJPmhkrb+/FjSaNl/9GkZgkilB31z1t2igPYWgZEo=:v3y2pqSyQXckfVAS94TgM+OS3rEgd3xvdBXFSKDeamo=', 6352778198, '2002-09-25', 'Male', 'Surat', 343543, 'sds.jpg', 546, 'guja', 'surat', 'mca', 'df34444445', '3 yera', 'fsdf', 'dsfs', 'assd', 'sdfsd', 'dsfs', NULL, 'ewrw', 'as', 'sd', '2025-07-11', 'Surat', 'Active', '2024-12-21 10:40:09', '2024-12-25 03:21:11'),
(54, 10, NULL, 'ati@gmail.com', 'Paladiya', 'asti', 'asti', 6352778198, '2002-09-25', 'Male', 'Surat', 343543, 'sds.jpg', 23, 'guja', 'surat', 'mca', 'df34444445', '3 yera', 'fsdf', 'dsfs', 'assd', 'sdfsd', 'dsfs', NULL, 'dfds', 'dsfs', 'dsfsd', '2029-02-09', 'Surat', 'Block', '2024-12-22 05:02:56', '2024-12-26 02:47:22'),
(55, 7, NULL, 'admin@gmail.com', 'Paladiya', 'asti', 'PBKDF2WithHmacSHA256:2048:IknO3cH0x5cv7jfrb5GEaxZpCQeR4J1B4K27c2jyGKw=:s6+OoLykAeKZsQP2F6T+8Ma3+F4VXChzaY31Lm+SoEA=', 6352778198, '2002-09-25', 'Female', 'Surat', NULL, 'IMG_424556921188images1.jpeg', 0, 'guja', 'surat', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Active', '2024-12-22 05:34:00', '2024-12-26 04:34:22'),
(56, 12, NULL, 'drashti@gmail.com', 'khut', 'asti', 'PBKDF2WithHmacSHA256:2048:IknO3cH0x5cv7jfrb5GEaxZpCQeR4J1B4K27c2jyGKw=:s6+OoLykAeKZsQP2F6T+8Ma3+F4VXChzaY31Lm+SoEA=', 6352778198, '2002-09-25', 'Male', 'Surat', 343543, 'IMG_1734969458560service-8.jpg', 34323, 'guja', 'surat', 'mca', 'df34444445', '3 yera', 'fsdf', NULL, 'assd', 'sdfsd', 'dsfs', NULL, 'sad', 'dsfs', 'wew', '2022-09-12', NULL, 'Active', '2024-12-22 05:37:19', '2024-12-26 04:37:49'),
(61, 10, 2, 'p@gmail.com', 'Paladiya', 'asti', 'PBKDF2WithHmacSHA256:2048:tYgyZk/tIpgwbmVPK2fKN+tXEZp37q0E8KqOgcfUeSI=:bS4i5qglqUcWzm3DBDoa6xHE8NgXnOkxWEVfC88Tg4U=', 6352778198, '2002-09-25', 'Male', 'Surat', 43435435, '', 3232, 'guja', 'surat', 'dfsf', '45344', '4', 'esr', NULL, 'rest', 'qer', 'rt', '2002-03-21', 'wr', 'dsfs', 'wqeqw', '2025-02-02', NULL, 'Active', '2024-12-22 09:18:06', '2024-12-22 15:54:08'),
(62, 12, 7, 'diya@gmail.com', 'Paladiya', 'diya', 'PBKDF2WithHmacSHA256:2048:jK7PT98DuyQHMznOw1LUbFU5RCnJ/SF/hQBE/EpX9oQ=:cK5rhCJi6rGRc7S50BVj3kqA3htBSPkgjnvDm7NjLOA=', 6352778198, '2002-09-25', 'Male', 'Surat', 3435439034, 'IMG_1734971299387service-4.jpg', 396500, 'gujarat', 'surat', 'mca', 'df34444445', '3 yera', 'mda', NULL, 'abcwebsite', 'Doctor', '10 am to 5pm', '2002-09-12', 'Hello iam nutrition doctor', 'carewebsite', 'nution.com', '2025-07-10', NULL, 'Active', '2024-12-22 09:43:45', '2024-12-26 04:40:58'),
(63, 12, 2, 'sti@gmail.com', 'Paladiya', 'asti', 'PBKDF2WithHmacSHA256:2048:feOSusaZuwG+NnpJdMYUuwkNpGPZtpe5ZvBRLAm1DSk=:08Lo/5GgA12LMtLDi21vMnuzPGS5Lg+12jZaDEQ6+zU=', 6352778198, NULL, 'Male', 'Surat', NULL, 'IMG_1734971299387service-4.jpg', 0, 'guja', 'surat', '', '', '', '', NULL, '', '', '', NULL, '', 'dsfs', '', '2025-07-09', NULL, 'Active', '2024-12-22 10:26:09', '2024-12-25 12:12:01'),
(64, 13, 7, 'ekta@gmail.com', 'kappor', 'ekta', 'PBKDF2WithHmacSHA256:2048:dUnJwLGcNvN9nJe/bOsIabjA+BeQ4FDPcorxKbjQdOQ=:VTYN0T3InIhHDir2ILwQZeqediHrq8i/wsDqgZRY/9g=', 6352778198, NULL, 'Male', 'Surat', NULL, '', 0, 'guja', 'surat', '', '', '', '', NULL, '', '', '', NULL, '', 'dsfs', '', '2025-07-13', NULL, 'Active', '2024-12-22 10:27:44', '2024-12-26 04:45:12'),
(65, 10, 7, 'xyz@gmail.com', 'Paladiya', 'asti', 'PBKDF2WithHmacSHA256:2048:a/HEon3iEsWMVvj3Y4jdQd2LlZdK3o1GtOZDY2iCPhg=:bqBry7s/3MWZRPi5t7gHEfHxShkIKefLqZ53fZm5MGs=', 6352778198, NULL, 'Male', 'Surat', NULL, '', 0, 'guja', 'surat', '', '', '', '', NULL, '', '', '', NULL, '', 'dsfs', '', '2025-07-10', NULL, 'Active', '2024-12-22 10:28:36', '2024-12-26 04:44:41'),
(66, 10, 3, 'medicine@gmail.com', 'Paladiya', 'asti', 'PBKDF2WithHmacSHA256:2048:VDHFlB9BKMs66G7I6HhAYBatFiACFOTAIMmW1553sQU=:w39auDr97GKvtYWI3LnPldUn+6GOCkkv3uVIq0hqxzs=', 6352778198, NULL, 'Male', 'Surat', NULL, '', 0, 'guja', 'surat', '', '', '', '', NULL, '', '', '', NULL, '', 'dsfs', '', '2025-10-17', NULL, 'Active', '2024-12-22 10:30:52', '2024-12-26 04:43:52'),
(67, 12, 7, 'vimalapaladiya@gmail.com', 'vimala', 'Paladiya', 'PBKDF2WithHmacSHA256:2048:rU12k1DD9TJ+BXOKGxZwTiQtm0kJZ7/q/wL8lRKUanc=:jvvWEwU/xJ2edK0GLKyWQYqhdHfPGeC+m0XmeoVG4P4=', 6352778198, '2002-09-25', 'Female', 'Surat', 8469892321, 'IMG_747544149311images1.jpeg', 395006, 'gujarat', 'surat', 'mca', 'as23092002', '2', 'MCA', NULL, 'xyzhospital', 'normal', '2 to 5 at afternoon', '2011-09-21', 'hello', 'dsfs', 'mpo.io', '2025-07-10', NULL, 'Active', '2024-12-22 11:00:51', '2024-12-26 04:43:37'),
(68, 12, 2, 'paladiyaasti25@gmail.com', 'asti', 'Paladiya', 'PBKDF2WithHmacSHA256:2048:lUhITR2bnOlnckDL4DjnaRWvsgKUAuGxMhz4+QvOvwQ=:oOJrWGjsT4K/dU1dRUROyxSGNfFVz0d29RnRuHTRoFk=', 6352778198, '2002-09-25', 'Female', 'Surat', 8468892321, 'IMG_17351650706741.jpg', 34323, 'Gujarat', 'surat', 'Gyanocologist', 'df34444445', '2 year', 'MD', NULL, 'restcare', 'normal', '2 to 5 at afternoon', '2002-03-21', 'heyy..\r\ni am gyconologist...\r\ni know about sometheir functionalityworking', 'dsfs', 'mpo.io', '2025-07-13', NULL, 'Active', '2024-12-25 22:17:50', '2024-12-26 04:54:56'),
(69, 12, 3, 'deep@gmail.com', 'deep', 'ganatra', 'PBKDF2WithHmacSHA256:2048:5jtXerY6kIYXkbgclPNtI3dFaRdVkt+TMEg10LXz/gc=:L/SVMy389/30qE6KQkHZgD+icnfKkeHyY426Oyn85iU=', 6352778198, '2002-09-25', 'Female', 'Surat', 8468892321, 'IMG_17351819954216.jpg', 34323, 'Gujarat', 'surat', 'Gyanocologist', 'df34444445', '2 year', 'MD', NULL, 'restcare', 'normal', '2 to 5 at afternoon', '2002-03-21', 'adsd', 'dsfs', 'mpo.io', '2025-10-21', NULL, 'Active', '2024-12-26 02:59:55', '2024-12-26 04:42:56'),
(70, 12, 2, 'astii@gmail.com', 'astii', 'palDITA', 'PBKDF2WithHmacSHA256:2048:/H1mzcdT5GUFSABbceFJp/sAv6hfn3qsBBeNOpdrcik=:NhTyHsLKRKfFeGK51DDb5Xhgi05mn29L1BjFOx0WYPI=', 89899098, '2002-09-25', 'Female', 'surat', 8468892321, '', 39820, 'Gujarat', 'surat', 'Gyanocologist', 'df34444445', '2 year', 'MD', NULL, 'restcare', 'normal', '3 to 5 at afternoon', '2025-03-21', 'hello', 'dsfs', 'mpo.io', '2025-07-13', NULL, 'Active', '2024-12-26 05:14:44', '2024-12-26 05:14:44');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_user` (`user_id`);

--
-- Indexes for table `career`
--
ALTER TABLE `career`
  ADD PRIMARY KEY (`id`),
  ADD KEY `career_user` (`user_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart_user` (`user_id`),
  ADD KEY `cart_product` (`product_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_role` (`role_id`);

--
-- Indexes for table `chat_master`
--
ALTER TABLE `chat_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_sender` (`sender_id`),
  ADD KEY `chat_reciever` (`reciever_id`);

--
-- Indexes for table `checkup_booking`
--
ALTER TABLE `checkup_booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_buss` (`bussiness_id`);

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`id`),
  ADD KEY `com_user` (`user_id`),
  ADD KEY `com_against` (`against_complain_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `health_record`
--
ALTER TABLE `health_record`
  ADD PRIMARY KEY (`id`),
  ADD KEY `check_book` (`book_id`),
  ADD KEY `record_paitent` (`patient_id`);

--
-- Indexes for table `health_wellness`
--
ALTER TABLE `health_wellness`
  ADD PRIMARY KEY (`id`),
  ADD KEY `health_user` (`user_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`id`),
  ADD KEY `job_user` (`user_id`),
  ADD KEY `job_career` (`career_id`);

--
-- Indexes for table `medical_report`
--
ALTER TABLE `medical_report`
  ADD PRIMARY KEY (`id`),
  ADD KEY `healthrecord_report` (`health_record_id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `detail_prd` (`product_id`),
  ADD KEY `detail_order` (`order_master_id`);

--
-- Indexes for table `order_master`
--
ALTER TABLE `order_master`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bill_no` (`bill_no`),
  ADD KEY `ord_user` (`buyer_user_id`);

--
-- Indexes for table `privacy_policy`
--
ALTER TABLE `privacy_policy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prd_user` (`user_id`),
  ADD KEY `prd_cat` (`category_id`);

--
-- Indexes for table `return_order`
--
ALTER TABLE `return_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `return_orderd` (`order_detail_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_user`
--
ALTER TABLE `subscription_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub_subuser` (`subscription_id`),
  ADD KEY `sub_user` (`user_id`);

--
-- Indexes for table `terms_condition`
--
ALTER TABLE `terms_condition`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_user` (`role_id`),
  ADD KEY `user_sub` (`subscription_id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wish_user` (`user_id`),
  ADD KEY `wish_prd` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `career`
--
ALTER TABLE `career`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `chat_master`
--
ALTER TABLE `chat_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `checkup_booking`
--
ALTER TABLE `checkup_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `health_record`
--
ALTER TABLE `health_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `health_wellness`
--
ALTER TABLE `health_wellness`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `medical_report`
--
ALTER TABLE `medical_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_master`
--
ALTER TABLE `order_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `privacy_policy`
--
ALTER TABLE `privacy_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `return_order`
--
ALTER TABLE `return_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `subscription_user`
--
ALTER TABLE `subscription_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `terms_condition`
--
ALTER TABLE `terms_condition`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blog`
--
ALTER TABLE `blog`
  ADD CONSTRAINT `blog_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `career`
--
ALTER TABLE `career`
  ADD CONSTRAINT `career_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `category`
--
ALTER TABLE `category`
  ADD CONSTRAINT `cat_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `chat_master`
--
ALTER TABLE `chat_master`
  ADD CONSTRAINT `chat_reciever` FOREIGN KEY (`reciever_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `chat_sender` FOREIGN KEY (`sender_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `checkup_booking`
--
ALTER TABLE `checkup_booking`
  ADD CONSTRAINT `book_buss` FOREIGN KEY (`bussiness_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `complain`
--
ALTER TABLE `complain`
  ADD CONSTRAINT `com_against` FOREIGN KEY (`against_complain_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `com_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `health_record`
--
ALTER TABLE `health_record`
  ADD CONSTRAINT `check_book` FOREIGN KEY (`book_id`) REFERENCES `checkup_booking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `record_paitent` FOREIGN KEY (`patient_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `health_wellness`
--
ALTER TABLE `health_wellness`
  ADD CONSTRAINT `health_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job`
--
ALTER TABLE `job`
  ADD CONSTRAINT `job_career` FOREIGN KEY (`career_id`) REFERENCES `career` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `job_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `medical_report`
--
ALTER TABLE `medical_report`
  ADD CONSTRAINT `healthrecord_report` FOREIGN KEY (`health_record_id`) REFERENCES `health_record` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `detail_order` FOREIGN KEY (`order_master_id`) REFERENCES `order_master` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_prd` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_master`
--
ALTER TABLE `order_master`
  ADD CONSTRAINT `ord_user` FOREIGN KEY (`buyer_user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `prd_cat` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prd_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `return_order`
--
ALTER TABLE `return_order`
  ADD CONSTRAINT `return_orderd` FOREIGN KEY (`order_detail_id`) REFERENCES `order_detail` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subscription_user`
--
ALTER TABLE `subscription_user`
  ADD CONSTRAINT `sub_subuser` FOREIGN KEY (`subscription_id`) REFERENCES `subscription` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sub_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `role_user` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_sub` FOREIGN KEY (`subscription_id`) REFERENCES `subscription` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wish_prd` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `wish_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
